import type { MetadataRoute } from 'next'
import { PAGES, SITE } from '@/lib/content'
import { listProducts } from '@/lib/store'

export const dynamic = 'force-dynamic'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await listProducts()
  const paths = ['/', ...products.flatMap((p) => p.variants.map((v) => `/casquette/${v.color_slug}`)), ...Object.keys(PAGES).map((p) => `/${p}`)]
  return paths.map((path) => ({ url: `${SITE.url}${path}` }))
}
