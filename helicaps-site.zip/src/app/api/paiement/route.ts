import { randomUUID } from 'node:crypto'
import { changed, parseItems, parsePromo, parseRelay, quoteCart, stripe } from '@/lib/cart'
import { allow, audit, readJson } from '@/lib/security'
import { DEMO, completeOrder, release, reserve } from '@/lib/store'

// Durée de vie minimale d'une session Stripe Checkout : 30 minutes. Le stock est réservé pendant ce temps.
const SESSION_MINUTES = 30

const fail = (error: string, status: number, extra?: object) => Response.json({ error, ...extra }, { status })

export async function POST(request: Request) {
  // Sans clé Stripe, on ne « simule » un paiement qu'en mode démo. Jamais sur une vraie boutique :
  // sinon une clé oubliée suffirait pour commander sans payer.
  if (!stripe && !DEMO) {
    audit('paiement_non_configure')
    return fail('Le paiement n’est pas encore disponible sur ce site.', 503)
  }
  // Chaque tentative réserve du stock pendant une demi-heure : on limite pour qu'un robot
  // ne puisse pas bloquer toutes les pièces à lui seul.
  if (!(await allow('paiement', request.headers, 6, 600))) {
    return fail('Trop de tentatives de paiement. Réessayez dans quelques minutes.', 429)
  }

  const body = await readJson(request)
  const items = parseItems(body?.items)
  const relay = parseRelay(body?.relay)
  if (!items?.length) return fail('Votre panier est vide.', 400)
  if (!relay) return fail('Choisissez un point relais pour payer.', 400)

  // Prix, stock, réduction et frais de port : recalculés ici, jamais repris du navigateur.
  const { promoId, ...quote } = await quoteCart(items, parsePromo(body?.promo))
  if (changed(items, quote.lines)) return fail('Le stock a changé. Votre panier a été mis à jour.', 409, { quote })
  if (quote.promo && !quote.promo.valid) return fail('Ce code n’existe pas ou a expiré.', 409, { quote })

  const reservationId = randomUUID()
  const expiresAt = new Date(Date.now() + SESSION_MINUTES * 60_000)
  const reserved = await reserve(
    reservationId,
    quote.lines.map((l) => ({ variant_id: l.variantId, quantity: l.quantity, unit_price_cents: l.unit_price_cents })),
    // Cinq minutes de marge : la confirmation de Stripe peut arriver juste après l'expiration.
    new Date(expiresAt.getTime() + 5 * 60_000),
  )
  if (!reserved) return fail('Une pièce vient d’être vendue. Votre panier a été mis à jour.', 409)

  // L'adresse de retour vient de la configuration, pas de la requête (qu'un attaquant peut maquiller).
  const origin = process.env.NEXT_PUBLIC_SITE_URL || process.env.URL || new URL(request.url).origin

  // Mode démo (pas de clé Stripe) : le paiement est simulé pour pouvoir tester le parcours.
  if (!stripe) {
    await completeOrder(reservationId, {
      stripe_session_id: `demo_${reservationId}`,
      email: 'client@exemple.fr',
      customer_name: 'Client de démonstration',
      phone: '06 00 00 00 00',
      relay_id: relay.id,
      relay_name: relay.name,
      relay_address: relay.address,
      relay_zip: relay.zip,
      relay_city: relay.city,
      subtotal_cents: quote.subtotal_cents,
      shipping_cents: quote.shipping_cents,
      discount_cents: quote.discount_cents,
      total_cents: quote.total_cents,
    })
    return Response.json({ url: `${origin}/commande/merci?demo=1` })
  }

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      locale: 'fr',
      expires_at: Math.floor(expiresAt.getTime() / 1000),
      line_items: quote.lines.map((l) => ({
        quantity: l.quantity,
        price_data: {
          currency: 'eur',
          unit_amount: l.unit_price_cents,
          product_data: { name: `${l.product_name}, ${l.color_name}`, description: 'Taille M' },
        },
      })),
      shipping_options: [
        {
          shipping_rate_data: {
            type: 'fixed_amount',
            display_name: `Point relais Mondial Relay : ${relay.name}, ${relay.zip} ${relay.city}`.slice(0, 100),
            fixed_amount: { amount: quote.shipping_cents, currency: 'eur' },
          },
        },
      ],
      discounts: promoId ? [{ promotion_code: promoId }] : undefined,
      phone_number_collection: { enabled: true },
      name_collection: { individual: { enabled: true } },
      metadata: {
        reservation_id: reservationId,
        relay_id: relay.id,
        relay_name: relay.name,
        relay_address: relay.address,
        relay_zip: relay.zip,
        relay_city: relay.city,
      },
      success_url: `${origin}/commande/merci?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?panier=1`,
    })
    return Response.json({ url: session.url })
  } catch (error) {
    await release(reservationId).catch(() => {}) // au pire, la réservation expire toute seule
    audit('stripe_session_erreur', { erreur: String(error).slice(0, 300) })
    return fail('Le paiement est indisponible pour le moment. Réessayez dans un instant.', 502)
  }
}

