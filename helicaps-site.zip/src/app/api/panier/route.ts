import { parseItems, parsePromo, quoteCart } from '@/lib/cart'
import { allow, readJson } from '@/lib/security'

// Le navigateur n'envoie que des identifiants et des quantités ; tout le reste vient de la base.
export async function POST(request: Request) {
  if (!(await allow('panier', request.headers, 60, 60))) {
    return Response.json({ error: 'Trop de demandes. Réessayez dans une minute.' }, { status: 429 })
  }
  const body = await readJson(request)
  const items = parseItems(body?.items)
  if (!items) return Response.json({ error: 'Panier illisible.' }, { status: 400 })

  // Un code promo ne se devine pas à la chaîne : dix essais par dix minutes, puis il est refusé d'office.
  const promo = parsePromo(body?.promo)
  const mayTry = !promo || (await allow('promo', request.headers, 10, 600))
  const { promoId: _, ...quote } = await quoteCart(items, mayTry ? promo : null)
  return Response.json(mayTry ? quote : { ...quote, promo: { code: promo, valid: false } })
}
