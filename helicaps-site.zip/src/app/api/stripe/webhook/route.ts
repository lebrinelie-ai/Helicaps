import { stripe } from '@/lib/cart'
import { audit } from '@/lib/security'
import { completeOrder, release } from '@/lib/store'

// Stripe appelle cette adresse quand un paiement aboutit ou qu'une session expire.
// La signature prouve que l'appel vient bien de Stripe : sans elle, n'importe qui pourrait créer une commande.
export async function POST(request: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET
  const signature = request.headers.get('stripe-signature')
  if (!stripe || !secret || !signature) return new Response('Webhook non configuré', { status: 400 })

  let event
  try {
    event = await stripe.webhooks.constructEventAsync(await request.text(), signature, secret)
  } catch {
    audit('webhook_signature_invalide')
    return new Response('Signature invalide', { status: 400 })
  }

  if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.expired') {
    const session = event.data.object
    const meta = session.metadata ?? {}
    if (!meta.reservation_id) return new Response('ok')

    if (event.type === 'checkout.session.expired') {
      await release(meta.reservation_id)
    } else if (session.mode === 'payment' && session.payment_status === 'paid') {
      audit('commande_payee', { session: session.id, total: session.amount_total })
      await completeOrder(meta.reservation_id, {
        stripe_session_id: session.id,
        email: session.customer_details?.email ?? '',
        customer_name: session.collected_information?.individual_name ?? session.customer_details?.name ?? '',
        phone: session.customer_details?.phone ?? '',
        relay_id: meta.relay_id ?? '',
        relay_name: meta.relay_name ?? '',
        relay_address: meta.relay_address ?? '',
        relay_zip: meta.relay_zip ?? '',
        relay_city: meta.relay_city ?? '',
        subtotal_cents: session.amount_subtotal ?? 0,
        shipping_cents: session.total_details?.amount_shipping ?? 0,
        discount_cents: session.total_details?.amount_discount ?? 0,
        total_cents: session.amount_total ?? 0,
      })
    }
  }
  return new Response('ok')
}
