import type { Metadata, Viewport } from 'next'
import { Geist } from 'next/font/google'
import { SITE } from '@/lib/content'
import './globals.css'

const geist = Geist({ subsets: ['latin'], weight: ['400', '500', '600'], variable: '--font-geist' })

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: `${SITE.name} : ${SITE.tagline}`, template: `%s · ${SITE.name}` },
  description: SITE.description,
  openGraph: { siteName: SITE.name, locale: 'fr_FR', type: 'website' },
}

// Chaque page est rendue à la demande : c'est ce qui permet de lui donner un nonce neuf (voir src/proxy.ts).
export const dynamic = 'force-dynamic'

export const viewport: Viewport = { themeColor: '#000000', colorScheme: 'dark', viewportFit: 'cover' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={geist.variable}>
      <body>{children}</body>
    </html>
  )
}
