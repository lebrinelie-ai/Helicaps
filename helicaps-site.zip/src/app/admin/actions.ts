'use server'

import { revalidatePath } from 'next/cache'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { getAdmin, signIn, signOut } from '@/lib/auth'
import { sendShippedEmail } from '@/lib/email'
import { allow, audit, isRealImage, isUuid, visitor } from '@/lib/security'
import * as store from '@/lib/store'

// Une action serveur est une adresse publique : chacune vérifie l'admin avant de faire quoi que ce soit,
// et ne fait confiance à aucun de ses arguments (ils viennent du navigateur).

/** Renvoie l'e-mail de l'admin, ou redirige vers la connexion. */
async function admin() {
  const email = await getAdmin()
  if (!email) redirect('/admin/connexion')
  return email
}

export async function login(_: string | null, form: FormData): Promise<string | null> {
  const head = await headers()
  // Cinq essais par quart d'heure : assez pour une faute de frappe, trop peu pour deviner un mot de passe.
  if (!(await allow('connexion', head, 5, 900))) return 'Trop d’essais. Réessayez dans un quart d’heure.'

  const ok = await signIn(String(form.get('email') ?? '').slice(0, 254), String(form.get('password') ?? '').slice(0, 200))
  audit(ok ? 'connexion_admin' : 'connexion_refusee', { visiteur: visitor(head) })
  if (!ok) {
    await new Promise((r) => setTimeout(r, 800)) // ralentit les essais en série
    return 'E-mail ou mot de passe incorrect.'
  }
  redirect('/admin')
}

export async function logout() {
  await signOut()
  redirect('/admin/connexion')
}

export async function adjustStock(variantId: string, delta: 1 | -1) {
  const by = await admin()
  if (!isUuid(variantId) || (delta !== 1 && delta !== -1)) return
  await store.adjustStock(variantId, delta)
  audit('stock_modifie', { par: by, coloris: variantId, delta })
  revalidatePath('/admin/produits')
}

export async function setActive(productId: string, active: boolean) {
  const by = await admin()
  if (!isUuid(productId)) return
  await store.setActive(productId, active === true)
  audit('produit_en_ligne', { par: by, produit: productId, en_ligne: active === true })
  revalidatePath('/admin/produits')
}

export async function uploadImage(form: FormData): Promise<{ url: string } | { error: string }> {
  const by = await admin()
  const file = form.get('file')
  if (!(file instanceof File) || !(await isRealImage(file))) return { error: 'Ce fichier n’est pas une photo.' }
  if (file.size > 3.5 * 1024 * 1024) return { error: 'Cette photo est trop lourde.' }
  const url = await store.uploadImage(file)
  audit('photo_envoyee', { par: by, octets: file.size })
  return { url }
}

export async function saveProduct(raw: unknown): Promise<store.FieldErrors> {
  const by = await admin()
  const input = store.cleanProductInput(raw)
  if (!input) return { variants: 'Formulaire illisible. Rechargez la page et recommencez.' }
  const errors = store.validateProduct(input)
  if (Object.keys(errors).length) return errors
  const id = await store.saveProduct(input)
  audit('produit_enregistre', { par: by, produit: id })
  revalidatePath('/admin/produits')
  redirect('/admin/produits')
}

export async function deleteProduct(productId: string) {
  const by = await admin()
  if (!isUuid(productId)) return
  await store.deleteProduct(productId)
  audit('produit_supprime', { par: by, produit: productId })
  revalidatePath('/admin/produits')
  redirect('/admin/produits')
}

/** Renvoie un message à afficher à l'admin. */
export async function shipOrder(orderId: string, tracking: string): Promise<string> {
  const by = await admin()
  if (!isUuid(orderId)) return 'Commande introuvable.'
  const order = await store.shipOrder(orderId, String(tracking ?? '').trim().slice(0, 40) || null)
  revalidatePath('/admin')
  if (!order) return 'Cette commande était déjà marquée comme expédiée.'
  audit('commande_expediee', { par: by, commande: order.number })
  const sent = await sendShippedEmail(order).catch(() => false)
  return sent
    ? `Commande ${order.number} expédiée. Le client a reçu un e-mail.`
    : `Commande ${order.number} expédiée. L’e-mail n’a pas pu partir : prévenez le client à ${order.email}.`
}
