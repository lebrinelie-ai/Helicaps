import { redirect } from 'next/navigation'
import { LoginForm } from '@/components/admin'
import { getAdmin } from '@/lib/auth'

export default async function Connexion() {
  if (await getAdmin()) redirect('/admin')
  return (
    <main className="mx-auto flex min-h-dvh max-w-100 flex-col justify-center gap-8 px-6 py-10">
      <div className="flex flex-col items-center gap-2 text-center">
        <p className="logo min-h-0">HELICAPS</p>
        <h1 className="text-card-title font-semibold">Espace propriétaire</h1>
      </div>
      <LoginForm />
    </main>
  )
}
