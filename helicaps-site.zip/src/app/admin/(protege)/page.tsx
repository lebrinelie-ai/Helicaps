import Link from 'next/link'
import { OrderList } from '@/components/admin'
import { requireAdmin } from '@/lib/auth'
import { listOrders } from '@/lib/store'

export default async function Commandes({ searchParams }: { searchParams: Promise<{ vue?: string }> }) {
  await requireAdmin()
  const shipped = (await searchParams).vue === 'expediees'
  const orders = (await listOrders()).filter((o) => o.status !== 'cancelled')
  const todo = orders.filter((o) => o.status === 'paid') // la plus ancienne d'abord : c'est la plus urgente
  const done = orders.filter((o) => o.status === 'shipped').reverse()

  const tabs = [
    { href: '/admin', label: `À expédier (${todo.length})`, current: !shipped },
    { href: '/admin?vue=expediees', label: `Expédiées (${done.length})`, current: shipped },
  ]

  return (
    <>
      <h1 className="text-title font-semibold">Commandes</h1>
      <nav aria-label="Filtrer les commandes" className="flex rounded-pill bg-surface p-1">
        {tabs.map((t) => (
          <Link
            key={t.href}
            href={t.href}
            aria-current={t.current ? 'page' : undefined}
            className={`flex min-h-(--tap-min) flex-1 items-center justify-center rounded-pill text-caption font-medium ${t.current ? 'bg-surface-raised text-text' : 'text-text-secondary'}`}
          >
            {t.label}
          </Link>
        ))}
      </nav>
      <OrderList orders={shipped ? done : todo} shipped={shipped} />
    </>
  )
}
