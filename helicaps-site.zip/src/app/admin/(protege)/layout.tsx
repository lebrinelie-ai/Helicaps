import { AdminTabs } from '@/components/admin'
import { requireAdmin } from '@/lib/auth'
import { DEMO } from '@/lib/store'
import { logout } from '../actions'

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin()
  return (
    <div className="mx-auto max-w-160 pb-[calc(var(--space-24)+env(safe-area-inset-bottom))]">
      <header className="sticky top-0 z-20 flex h-(--nav-h) items-center justify-between border-b border-nav-border bg-nav-bg pr-2 pl-5 backdrop-blur-[20px] backdrop-saturate-[1.8]">
        <p className="logo min-h-0 pl-0">HELICAPS</p>
        <form action={logout}>
          <button type="submit" className="min-h-(--tap-min) px-3 text-caption text-text-secondary">
            Se déconnecter
          </button>
        </form>
      </header>
      {DEMO && (
        <p className="mx-4 mt-4 rounded-sm bg-surface-raised px-4 py-3 text-caption text-text-secondary">
          Mode démo : les données sont enregistrées sur cet ordinateur et les paiements sont simulés.
        </p>
      )}
      <main className="flex flex-col gap-6 px-4 pt-6">{children}</main>
      <AdminTabs />
    </div>
  )
}
