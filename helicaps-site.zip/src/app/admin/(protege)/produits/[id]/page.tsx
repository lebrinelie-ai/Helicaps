import { notFound } from 'next/navigation'
import { ProductForm } from '@/components/product-form'
import { requireAdmin } from '@/lib/auth'
import { listProducts } from '@/lib/store'

// /admin/produits/nouveau : formulaire vide. /admin/produits/<id> : modification.
export default async function Produit({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin()
  const { id } = await params
  const product = id === 'nouveau' ? undefined : (await listProducts(true)).find((p) => p.id === id)
  if (id !== 'nouveau' && !product) notFound()
  return (
    <>
      <h1 className="text-title font-semibold">{product ? 'Modifier la casquette' : 'Ajouter une casquette'}</h1>
      <ProductForm product={product} />
    </>
  )
}
