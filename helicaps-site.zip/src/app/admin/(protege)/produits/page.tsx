import Link from 'next/link'
import { ProductCard } from '@/components/admin'
import { requireAdmin } from '@/lib/auth'
import { listProducts } from '@/lib/store'

export default async function Produits() {
  await requireAdmin()
  const products = await listProducts(true)
  return (
    <>
      <h1 className="text-title font-semibold">Produits</h1>
      <Link href="/admin/produits/nouveau" className="btn btn-primary">
        Ajouter une casquette
      </Link>
      <ul className="flex flex-col gap-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </ul>
      {products.length === 0 && <p className="py-10 text-center text-text-secondary">Aucune casquette pour le moment.</p>}
    </>
  )
}
