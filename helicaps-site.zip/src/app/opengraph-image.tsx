import { ImageResponse } from 'next/og'
import { SITE } from '@/lib/content'

export const alt = `${SITE.name} : ${SITE.tagline}`
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

// Image de partage (réseaux, messageries). Les couleurs sont celles de design/tokens.css,
// recopiées ici car ce rendu n'a pas accès aux variables CSS.
export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 36, background: 'radial-gradient(ellipse 60% 55% at 50% 58%, #2C2C2C 0%, #141414 55%, #000000 100%)', color: '#F2EFEA' }}>
        <div style={{ fontSize: 34, fontWeight: 600, letterSpacing: '0.34em', paddingLeft: '0.34em' }}>HELICAPS</div>
        <div style={{ fontSize: 76, fontWeight: 600, letterSpacing: '-0.03em', textAlign: 'center', maxWidth: 900, lineHeight: 1.05 }}>{SITE.tagline}</div>
      </div>
    ),
    size,
  )
}
