import { CartProvider } from '@/components/cart'
import { Footer, Nav } from '@/components/chrome'

export default function BoutiqueLayout({ children }: { children: React.ReactNode }) {
  return (
    <CartProvider>
      <a href="#contenu" className="btn btn-secondary sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-30">
        Aller au contenu
      </a>
      <Nav />
      <main id="contenu">{children}</main>
      <Footer />
    </CartProvider>
  )
}
