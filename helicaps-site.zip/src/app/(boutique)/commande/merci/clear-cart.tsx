'use client'

import { useEffect } from 'react'
import { useCart } from '@/components/cart'

/** La commande est payée : on vide le panier gardé dans le navigateur. */
export function ClearCart() {
  const { clear } = useCart()
  useEffect(clear, [clear])
  return null
}
