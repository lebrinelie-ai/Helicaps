import type { Metadata } from 'next'
import Link from 'next/link'
import { stripe } from '@/lib/cart'
import { ClearCart } from './clear-cart'

export const metadata: Metadata = { title: 'Merci pour votre commande', robots: { index: false } }

export default function Merci() {
  const demo = !stripe
  return (
    <section className="mx-auto flex max-w-160 flex-col items-center gap-5 px-6 pt-(--section-gap) text-center">
      <ClearCart />
      <h1 className="text-title font-semibold text-balance">Merci pour votre commande.</h1>
      <p className="text-text-secondary">
        {demo
          ? 'Mode démo : aucun paiement n’a été réalisé. La commande apparaît dans l’admin, onglet Commandes.'
          : 'Votre paiement est confirmé. Vous allez recevoir un reçu par e-mail, puis un second message dès que votre casquette sera expédiée vers votre point relais.'}
      </p>
      <Link href="/" className="btn btn-secondary mt-2">
        Retour à l’accueil
      </Link>
    </section>
  )
}
