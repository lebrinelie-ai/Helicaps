import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { ProductView } from '@/components/product-view'
import { SITE } from '@/lib/content'
import { euros } from '@/lib/format'
import { listProducts } from '@/lib/store'

export const dynamic = 'force-dynamic'

type Props = { params: Promise<{ coloris: string }> }

async function find(slug: string) {
  const product = (await listProducts()).find((p) => p.variants.some((v) => v.color_slug === slug))
  return product ? { product, variant: product.variants.find((v) => v.color_slug === slug)! } : null
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const found = await find((await params).coloris)
  if (!found) return {}
  const { product, variant } = found
  const image = variant.images[0]?.url
  return {
    title: `${product.name}, ${variant.color_name.toLowerCase()}`,
    description: `${product.name}, coloris ${variant.color_name.toLowerCase()}. ${euros(product.price_cents)}, série limitée à ${variant.stock_initial} pièces.`,
    alternates: { canonical: `/casquette/${variant.color_slug}` },
    // Un SVG provisoire n'est pas une image de partage valable : on garde alors celle du site.
    openGraph: image && !image.endsWith('.svg') ? { images: [image] } : undefined,
  }
}

export default async function PageProduit({ params }: Props) {
  const found = await find((await params).coloris)
  if (!found) notFound()
  const { product, variant } = found

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ProductGroup',
    name: product.name,
    description: product.description,
    brand: { '@type': 'Brand', name: SITE.name },
    variesBy: 'https://schema.org/color',
    hasVariant: product.variants.map((v) => ({
      '@type': 'Product',
      name: `${product.name}, ${v.color_name}`,
      color: v.color_name,
      size: 'M',
      image: v.images.map((i) => new URL(i.url, SITE.url).href),
      offers: {
        '@type': 'Offer',
        url: `${SITE.url}/casquette/${v.color_slug}`,
        price: (product.price_cents / 100).toFixed(2),
        priceCurrency: 'EUR',
        availability: `https://schema.org/${v.stock > 0 ? 'InStock' : 'SoldOut'}`,
      },
    })),
  }

  return (
    <>
      {/* « < » échappé : le nom et la description viennent de l'admin, ils ne doivent pas pouvoir fermer la balise. */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }} />
      <ProductView product={product} initial={variant.color_slug} />
    </>
  )
}
