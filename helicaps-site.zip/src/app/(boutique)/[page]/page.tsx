import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { PAGES } from '@/lib/content'

// Pages d'information (CGV, mentions légales…) : le texte est dans src/lib/content.ts.
// Une adresse inconnue passe par notFound() plus bas (dynamicParams = false donne une erreur 500 chez Netlify).
export const generateStaticParams = () => Object.keys(PAGES).map((page) => ({ page }))

type Props = { params: Promise<{ page: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  return { title: PAGES[(await params).page]?.titre }
}

export default async function PageInfo({ params }: Props) {
  const page = PAGES[(await params).page]
  if (!page) notFound()
  return (
    <article className="mx-auto flex max-w-180 flex-col gap-8 px-6 pt-(--section-gap)">
      <h1 className="text-title font-semibold text-balance">{page.titre}</h1>
      {page.sections.map((s, i) => (
        <section key={i} className="flex flex-col gap-2">
          {s.titre && <h2 className="text-card-title font-semibold">{s.titre}</h2>}
          <p className="text-text-secondary">{s.texte}</p>
        </section>
      ))}
    </article>
  )
}
