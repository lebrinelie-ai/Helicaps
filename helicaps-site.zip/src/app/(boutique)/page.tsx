import { ColorBlock } from '@/components/color-block'
import { Icon, Photo, type IconName } from '@/components/ui'
import { AVIS, RESEAUX, SITE, TAILLE } from '@/lib/content'
import { compter, euros } from '@/lib/format'
import { FREE_SHIPPING_FROM_CENTS, SHIPPING_CENTS } from '@/lib/pricing'
import { listProducts } from '@/lib/store'

// Le stock affiché vient de la base à chaque visite, jamais d'une page figée.
export const dynamic = 'force-dynamic'

const REASSURANCE: { icon: IconName; titre: string; texte: string }[] = [
  { icon: 'pin', titre: 'Point relais Mondial Relay', texte: `Livraison à ${euros(SHIPPING_CENTS)}` },
  { icon: 'box', titre: 'Livraison offerte', texte: `Dès ${euros(FREE_SHIPPING_FROM_CENTS)} d’achat` },
  { icon: 'lock', titre: 'Paiement sécurisé', texte: 'Données bancaires chiffrées' },
  { icon: 'clock', titre: 'Expédiée sous 2 jours', texte: 'Suivi de colis inclus' },
]

// Place de chaque casquette dans la scène (mobile, puis desktop), reprise des maquettes.
const SCENE = [
  'left-[12.8%] top-[37.6%] z-10 w-[74.4%] md:left-[23%] md:top-[30%] md:w-[54%]',
  'left-[-3.6%] top-[18.8%] w-[59%] -rotate-[8deg] opacity-[0.92] md:left-[2%] md:top-[12%] md:w-[44%]',
  'right-[-3.6%] top-[18.8%] w-[59%] -scale-x-100 rotate-[8deg] opacity-[0.92] md:right-[2%] md:top-[12%] md:w-[44%]',
]

export default async function Accueil() {
  const products = await listProducts()
  const variants = products.flatMap((p) => p.variants)
  const dispo = variants.reduce((sum, v) => sum + v.stock, 0)
  const total = variants.reduce((sum, v) => sum + v.stock_initial, 0)
  const vedette = products[0]

  return (
    <>
      <section className="mx-auto flex max-w-(--page-max) flex-col items-center gap-4 px-6 pt-11 text-center md:gap-5 md:px-(--page-gutter) md:pt-22">
        <h1 className="max-w-220 text-display font-semibold text-balance">{SITE.tagline}</h1>
        {vedette && (
          <>
            <p className="text-body text-text-secondary">
              {compter(products.length, 'casquette')}. {compter(variants.length, 'coloris', 'coloris', false)}. {compter(total, 'pièce')}.
            </p>
            <div className="mt-2 flex flex-col items-center gap-3 md:flex-row md:gap-5">
              <a href="#coloris" className="btn btn-primary">
                Choisir mon coloris
              </a>
              <p className="text-caption text-text-secondary">
                {euros(vedette.price_cents)}, {TAILLE.charAt(0).toLowerCase() + TAILLE.slice(1)}
              </p>
            </div>
          </>
        )}
      </section>

      {vedette && (
        <section aria-label="Les coloris" className="mx-auto mt-8 flex max-w-(--page-max) flex-col items-center gap-4 md:mt-10 md:gap-6 md:px-(--page-gutter)">
          <div className="stage-hero w-full overflow-hidden md:rounded-2xl">
            <div className="relative mx-auto aspect-[390/340] w-full max-w-240 md:aspect-[960/520]">
              {vedette.variants.slice(0, 3).map((v, i) => (
                <div key={v.id} className={`absolute aspect-[3/2] ${SCENE[i]}`}>
                  {v.images[0] && <Photo src={v.images[0].url} alt={v.images[0].alt} sizes="(min-width: 768px) 520px, 75vw" preload={i === 0} />}
                </div>
              ))}
            </div>
          </div>
          <p className="text-caption font-semibold text-accent">
            {dispo} pièce{dispo > 1 ? 's' : ''} disponible{dispo > 1 ? 's' : ''} sur {total}
          </p>
        </section>
      )}

      <div id="coloris">
        {products.map((p) => (
          <ColorBlock
            key={p.id}
            product={p}
            // Un seul modèle : le titre de la maquette. Plusieurs : chaque bloc porte le nom de sa casquette.
            titre={
              products.length > 1
                ? [p.name]
                : [
                    `${compter(p.variants.length, 'coloris', 'coloris', false)}.`,
                    ...(p.variants.every((v) => v.stock_initial === p.variants[0].stock_initial)
                      ? [`${compter(p.variants[0].stock_initial, 'pièce')} chacun.`]
                      : []),
                  ]
            }
          />
        ))}
        {products.length === 0 && <p className="px-6 pt-(--section-gap) text-center text-text-secondary">La boutique rouvre bientôt.</p>}
      </div>

      <section id="livraison" aria-labelledby="titre-livraison" className="mx-auto flex max-w-(--page-max) flex-col gap-5 px-4 pt-(--section-gap) md:px-(--page-gutter)">
        <h2 id="titre-livraison" className="px-2 text-title font-semibold md:sr-only">
          Livraison et paiement
        </h2>
        <ul className="grid grid-cols-2 gap-3 md:grid-cols-[repeat(auto-fit,minmax(260px,1fr))] md:gap-4">
          {REASSURANCE.map((r) => (
            <li key={r.titre} className="flex flex-col gap-3.5 rounded-md bg-surface p-5 md:gap-4 md:rounded-lg md:p-6">
              <span className="flex size-10 items-center justify-center rounded-pill bg-accent-tint text-accent md:size-11">
                <Icon name={r.icon} />
              </span>
              <div className="flex flex-col gap-1">
                <p className="leading-tight font-semibold">{r.titre}</p>
                <p className="text-caption text-text-secondary">{r.texte}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {AVIS.length > 0 && (
        <section id="avis" aria-labelledby="titre-avis" className="mx-auto flex max-w-(--page-max) flex-col gap-5 pt-(--section-gap)">
          <h2 id="titre-avis" className="px-6 text-title font-semibold md:px-(--page-gutter)">
            Avis clients
          </h2>
          <ul className="flex snap-x snap-mandatory scroll-px-4 gap-3 overflow-x-auto px-4 md:scroll-px-(--page-gutter) md:px-(--page-gutter)">
            {AVIS.map((a, i) => (
              <li key={i} className="w-75 flex-none snap-start md:w-90">
                <figure className="flex h-full flex-col gap-3 rounded-lg bg-surface p-5">
                  <p className="text-caption font-semibold text-accent">
                    <span aria-hidden="true">{'★'.repeat(a.note)}</span>
                    <span className="sr-only">Note : {a.note} sur 5</span>
                  </p>
                  <blockquote>« {a.texte} »</blockquote>
                  <figcaption className="text-caption text-text-secondary">
                    {a.auteur}, coloris {a.coloris}
                  </figcaption>
                </figure>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section aria-labelledby="titre-reseaux" className="mx-auto flex max-w-(--page-max) flex-col gap-5 px-4 pt-(--section-gap) md:px-(--page-gutter)">
        <h2 id="titre-reseaux" className="px-2 text-title font-semibold">
          Suivre les prochains drops
        </h2>
        <ul className="overflow-hidden rounded-md bg-surface md:max-w-140">
          {RESEAUX.map((r) => (
            <li key={r.id} className="group">
              <a href={r.url} className="flex min-h-15 items-center gap-3.5 px-4">
                <span className="flex size-8 flex-none items-center justify-center rounded-xs bg-disabled-bg">
                  <Icon name={r.id} size={18} />
                </span>
                <span className="flex min-h-15 flex-1 items-center justify-between gap-2 border-b border-line-strong group-last:border-0">
                  <span>{r.name}</span>
                  <span className="flex items-center gap-1 text-caption text-text-secondary">
                    {r.handle}
                    <Icon name="chevron" size={18} />
                  </span>
                </span>
              </a>
            </li>
          ))}
        </ul>
      </section>
    </>
  )
}
