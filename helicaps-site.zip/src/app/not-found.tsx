import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-5 px-6 text-center">
      <Link href="/" className="logo">
        HELICAPS
      </Link>
      <h1 className="text-title font-semibold">Cette page n’existe pas.</h1>
      <Link href="/" className="btn btn-primary">
        Retour à l’accueil
      </Link>
    </main>
  )
}
