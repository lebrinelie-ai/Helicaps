// Page isolée qui affiche le widget officiel Mondial Relay (« Parcel Shop Picker » v4) : un plugin jQuery
// qui dessine la recherche par code postal, la liste et la carte Leaflet.
//
// Ce widget est du code que nous ne maîtrisons pas, et il a besoin de permissions (scripts « en ligne »)
// que le reste du site refuse. Il vit donc ici, seul, et le panier l'affiche dans une <iframe sandbox> :
// il ne peut lire ni la page de la boutique, ni le panier, ni les cookies. Il n'a qu'un moyen de parler
// au site : envoyer le point relais choisi par postMessage (voir src/components/relay-picker.tsx).

// Code enseigne sur 8 caractères. « BDTEST  » est le code de test public (le widget affiche alors un avertissement).
const BRAND = (process.env.NEXT_PUBLIC_MONDIAL_RELAY_BRAND || 'BDTEST').slice(0, 8).padEnd(8, ' ')

// L'empreinte (integrity) fait refuser par le navigateur un fichier qui aurait été modifié sur le CDN.
// Le script de Mondial Relay n'est pas versionné : impossible de lui en donner une.
const JQUERY = ['https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js', 'sha384-1H217gwSVyLSIfaLxHbE7dRb3v4mYCKbpQvzx0cegeju1MVsGrX5xXxAvs/HgeFs']
const LEAFLET_JS = ['https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', 'sha384-cxOPjt7s7Iz04uaHJceBmS+qpjv2JkIHNVcuOrM+YHwZOmJGBXI00mdUXEq65HTH']
const LEAFLET_CSS = ['https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', 'sha384-sHL9NAb7lN7rfvG5lfHpm643Xkcjzp4jFvuavGOndn6pjVqS6ny56CAt3nsEVT4H']
const WIDGET = 'https://widget.mondialrelay.com/parcelshop-picker/jquery.plugin.mondialrelay.parcelshoppicker.min.js'

// Politique propre à cette page : uniquement ce dont le widget a besoin, et seul notre site peut l'encadrer.
const CSP = [
  "default-src 'none'",
  "script-src 'unsafe-inline' https://ajax.googleapis.com https://unpkg.com https://widget.mondialrelay.com",
  "style-src 'unsafe-inline' https://unpkg.com https://widget.mondialrelay.com https://fonts.googleapis.com",
  "img-src data: https://unpkg.com https://*.mondialrelay.com https://*.tile.openstreetmap.org",
  'font-src https://fonts.gstatic.com https://widget.mondialrelay.com',
  'connect-src https://widget.mondialrelay.com',
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'self'",
].join('; ')

// JSON sûr à écrire dans une balise <script>.
const js = (value: string) => JSON.stringify(value).replace(/</g, '\\u003c')

export function GET(request: Request) {
  const cp = new URL(request.url).searchParams.get('cp') ?? ''
  const postCode = /^\d{5}$/.test(cp) ? cp : ''

  const html = `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Choix du point relais Mondial Relay</title>
<link rel="stylesheet" href="${LEAFLET_CSS[0]}" integrity="${LEAFLET_CSS[1]}" crossorigin="anonymous">
<style>html, body { margin: 0; background: #fff; color: #000; font-family: system-ui, sans-serif; } p { padding: 16px; }</style>
</head>
<body>
<div id="Zone_Widget"><p>Chargement de la carte des points relais…</p></div>
<input type="hidden" id="relais-id">
<script>
  // Toute erreur du widget est signalée au panier, qui peut alors l'expliquer au client.
  window.addEventListener('error', function (e) {
    parent.postMessage({ type: 'helicaps-relais', error: String(e.message || (e.target && (e.target.src || e.target.href)) || 'erreur').slice(0, 200) }, '*')
  }, true)
</script>
<script src="${JQUERY[0]}" integrity="${JQUERY[1]}" crossorigin="anonymous"></script>
<script src="${LEAFLET_JS[0]}" integrity="${LEAFLET_JS[1]}" crossorigin="anonymous"></script>
<script src="${WIDGET}"></script>
<script>
  var clean = function (v) { return String(v == null ? '' : v).replace(/\\s+/g, ' ').trim() }
  try {
    jQuery('#Zone_Widget').empty().MR_ParcelShopPicker({
      Target: '#relais-id',
      Brand: ${js(BRAND)},
      Country: 'FR',
      PostCode: ${js(postCode)},
      ColLivMod: '24R',
      NbResults: '7',
      Responsive: true,
      ShowResultsOnMap: true,
      DisplayMapInfo: true,
      OnParcelShopSelected: function (d) {
        parent.postMessage({ type: 'helicaps-relais', relay: {
          id: clean(d.ID), name: clean(d.Nom), address: clean(d.Adresse1 + ' ' + (d.Adresse2 || '')), zip: clean(d.CP), city: clean(d.Ville)
        } }, '*')
      }
    })
  } catch (e) {
    document.getElementById('Zone_Widget').innerHTML = '<p>La carte des points relais ne se charge pas. Vérifiez votre connexion et réessayez.</p>'
  }
</script>
</body>
</html>`

  return new Response(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Security-Policy': CSP,
      'X-Frame-Options': 'SAMEORIGIN',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'Cache-Control': 'public, max-age=3600',
    },
  })
}
