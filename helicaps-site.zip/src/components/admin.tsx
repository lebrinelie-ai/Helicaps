'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useActionState, useRef, useState, useTransition } from 'react'
import { adjustStock, login, setActive, shipOrder } from '@/app/admin/actions'
import { dateFr, euros } from '@/lib/format'
import type { Order, Product } from '@/lib/types'
import { Icon, Photo } from './ui'

export function LoginForm() {
  const [error, action, pending] = useActionState(login, null)
  return (
    <form action={action} className="flex flex-col gap-5">
      <div className="flex flex-col gap-2">
        <label htmlFor="email" className="text-caption text-text-secondary">
          E-mail
        </label>
        <input id="email" name="email" type="email" required autoComplete="username" className="field" />
      </div>
      <div className="flex flex-col gap-2">
        <label htmlFor="password" className="text-caption text-text-secondary">
          Mot de passe
        </label>
        <input id="password" name="password" type="password" required autoComplete="current-password" className="field" aria-describedby="login-erreur" />
      </div>
      <p id="login-erreur" role="alert" className="text-caption font-medium empty:hidden">
        {error}
      </p>
      <button type="submit" className="btn btn-primary" disabled={pending}>
        {pending ? 'Connexion…' : 'Se connecter'}
      </button>
    </form>
  )
}

export function AdminTabs() {
  const path = usePathname()
  const tabs = [
    { href: '/admin', label: 'Commandes', icon: 'box', current: path === '/admin' },
    { href: '/admin/produits', label: 'Produits', icon: 'tag', current: path.startsWith('/admin/produits') },
  ] as const
  return (
    <nav aria-label="Sections de l’admin" className="fixed inset-x-0 bottom-0 z-20 border-t border-nav-border bg-nav-bg pb-[env(safe-area-inset-bottom)] backdrop-blur-[20px] backdrop-saturate-[1.8]">
      <ul className="mx-auto flex max-w-160">
        {tabs.map((t) => (
          <li key={t.href} className="flex-1">
            <Link
              href={t.href}
              aria-current={t.current ? 'page' : undefined}
              className={`flex h-15 flex-col items-center justify-center gap-0.5 text-footnote font-medium ${t.current ? 'text-text' : 'text-text-secondary'}`}
            >
              <Icon name={t.icon} />
              {t.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}

// ---------- Commandes ----------

export function OrderList({ orders, shipped }: { orders: Order[]; shipped: boolean }) {
  const [message, setMessage] = useState('')
  return (
    <>
      <p role="status" className="rounded-sm bg-surface-raised px-4 py-3 text-caption font-medium empty:hidden">
        {message}
      </p>
      {orders.length === 0 && <p className="py-10 text-center text-text-secondary">{shipped ? 'Aucune commande expédiée pour le moment.' : 'Aucune commande à expédier.'}</p>}
      <ul className="flex flex-col gap-4">
        {orders.map((o) => (
          <li key={o.id} className="flex flex-col gap-4 rounded-lg bg-surface p-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-card-title font-semibold">{o.number}</h2>
              <p className="font-semibold">{euros(o.total_cents, true)}</p>
            </div>
            <p className="text-caption text-text-secondary">
              Commandée le {dateFr(o.created_at)}
              {o.shipped_at && (
                <>
                  <br />
                  Expédiée le {dateFr(o.shipped_at)}
                  {o.tracking_number && `, suivi ${o.tracking_number}`}
                </>
              )}
            </p>
            <div>
              <p className="font-semibold">{o.customer_name || 'Nom non renseigné'}</p>
              <p className="text-caption break-all text-text-secondary">
                {o.email}
                {o.phone && ` · ${o.phone}`}
              </p>
            </div>
            <ul className="border-y border-line-strong py-3">
              {o.items.map((item, i) => (
                <li key={i}>
                  {item.product_name}, {item.color_name} × {item.quantity}
                </li>
              ))}
            </ul>
            <div className="flex items-end justify-between gap-3">
              <p className="text-caption text-text-secondary">
                Point relais
                <span className="block text-body font-semibold text-text">{o.relay_name}</span>
                {o.relay_address}
                <br />
                {o.relay_zip} {o.relay_city}
                <br />
                Identifiant Mondial Relay : <span className="font-semibold text-text">{o.relay_id}</span>
              </p>
              <CopyButton text={o.relay_id} label="l’identifiant du point relais" />
            </div>
            {o.status === 'paid' && <ShipButton order={o} onDone={setMessage} />}
          </li>
        ))}
      </ul>
    </>
  )
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      className="btn btn-secondary h-(--tap-min) flex-none px-4 text-caption"
      aria-label={`Copier ${label}`}
      onClick={async () => {
        await navigator.clipboard.writeText(text)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
      }}
    >
      <span aria-live="polite">{copied ? 'Copié' : 'Copier'}</span>
    </button>
  )
}

function ShipButton({ order, onDone }: { order: Order; onDone: (message: string) => void }) {
  const dialog = useRef<HTMLDialogElement>(null)
  const [pending, start] = useTransition()
  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => dialog.current?.showModal()}>
        Marquer comme expédiée
      </button>
      <dialog ref={dialog} className="sheet" aria-labelledby={`expedier-${order.id}`}>
        <form
          className="flex flex-col gap-5"
          action={(form) =>
            start(async () => {
              onDone(await shipOrder(order.id, String(form.get('tracking') ?? '')))
              dialog.current?.close()
            })
          }
        >
          <h3 id={`expedier-${order.id}`} className="text-card-title font-semibold">
            Expédier la commande {order.number} ?
          </h3>
          <p className="text-caption text-text-secondary">Le client recevra un e-mail pour le prévenir.</p>
          <div className="flex flex-col gap-2">
            <label htmlFor={`suivi-${order.id}`} className="text-caption text-text-secondary">
              Numéro de suivi (facultatif)
            </label>
            <input id={`suivi-${order.id}`} name="tracking" className="field" autoComplete="off" maxLength={40} />
          </div>
          <div className="flex flex-col gap-3">
            <button type="submit" className="btn btn-primary" disabled={pending}>
              {pending ? 'Envoi…' : 'Confirmer l’expédition'}
            </button>
            <button type="button" className="btn btn-secondary" onClick={() => dialog.current?.close()}>
              Annuler
            </button>
          </div>
        </form>
      </dialog>
    </>
  )
}

// ---------- Produits ----------

export function ProductCard({ product }: { product: Product }) {
  const [pending, start] = useTransition()
  const image = product.variants[0]?.images[0]
  return (
    <li className="flex flex-col gap-4 rounded-lg bg-surface p-5" aria-busy={pending}>
      <div className="flex items-center gap-4">
        <div className="stage-card relative size-18 flex-none overflow-hidden rounded-sm">{image && <Photo src={image.url} alt="" sizes="72px" />}</div>
        <div className="min-w-0 flex-1">
          <h2 className="font-semibold">{product.name}</h2>
          <p className="text-caption text-text-secondary">{euros(product.price_cents)}</p>
        </div>
        <Link href={`/admin/produits/${product.id}`} className="btn btn-secondary h-(--tap-min) flex-none px-4 text-caption">
          Modifier
        </Link>
      </div>

      <ul className="border-y border-line-strong py-1">
        {product.variants.map((v) => (
          <li key={v.id} className="flex items-center gap-3 py-1">
            <span aria-hidden="true" className="size-6 flex-none rounded-pill" style={{ background: v.swatch_hex, boxShadow: 'var(--swatch-inner-ring)' }} />
            <span className="flex-1">{v.color_name}</span>
            <div role="group" aria-label={`Stock, ${v.color_name}`} className="flex items-center rounded-pill bg-surface-raised">
              <button type="button" className="icon-btn" aria-label="Retirer une pièce" disabled={pending || v.stock < 1} onClick={() => start(() => adjustStock(v.id, -1))}>
                <Icon name="minus" size={18} />
              </button>
              <span className="min-w-8 text-center font-semibold" aria-live="polite">
                {v.stock}
              </span>
              <button type="button" className="icon-btn" aria-label="Ajouter une pièce" disabled={pending} onClick={() => start(() => adjustStock(v.id, 1))}>
                <Icon name="plus" size={18} />
              </button>
            </div>
          </li>
        ))}
      </ul>

      <button
        type="button"
        role="switch"
        aria-checked={product.is_active}
        disabled={pending}
        className="flex min-h-(--tap-min) items-center justify-between gap-3 text-left"
        onClick={() => start(() => setActive(product.id, !product.is_active))}
      >
        <span>
          En ligne
          <span className="block text-caption text-text-secondary">{product.is_active ? 'Visible par les clients' : 'Cachée aux clients'}</span>
        </span>
        <span aria-hidden="true" className={`flex h-8 w-13 flex-none items-center rounded-pill p-0.5 transition-colors duration-(--dur-fast) ${product.is_active ? 'bg-text' : 'bg-inactive'}`}>
          <span className={`size-7 rounded-pill bg-bg transition-transform duration-(--dur-fast) ${product.is_active ? 'translate-x-5' : ''}`} />
        </span>
      </button>
    </li>
  )
}
