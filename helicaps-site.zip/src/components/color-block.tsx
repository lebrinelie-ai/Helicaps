'use client'

import Link from 'next/link'
import { useState } from 'react'
import { casquetteDeCouleur, euros } from '@/lib/format'
import type { Product } from '@/lib/types'
import { Photo, Rarity, Swatches } from './ui'

/** Bloc coloris de l'accueil : grande photo, pastilles, rareté, lien vers la page du coloris choisi. */
export function ColorBlock({ product, titre }: { product: Product; titre: string[] }) {
  const [picked, setPicked] = useState((product.variants.find((v) => v.stock > 0) ?? product.variants[0])?.id)
  const variant = product.variants.find((v) => v.id === picked)
  if (!variant) return null

  return (
    <section className="mx-auto flex max-w-(--page-max) flex-col gap-5 px-4 pt-(--section-gap) md:grid md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] md:grid-rows-[1fr_auto_auto_1fr] md:gap-x-8 md:gap-y-7 md:px-(--page-gutter)">
      <h2 className="px-2 text-title font-semibold md:col-start-2 md:row-start-2 md:px-8">
        {titre.map((ligne) => (
          <span key={ligne} className="block">
            {ligne}
          </span>
        ))}
      </h2>

      <div className="flex flex-col overflow-hidden rounded-xl bg-surface md:contents">
        <div className="stage-card relative h-72.5 md:col-start-1 md:row-span-4 md:row-start-1 md:h-auto md:min-h-130 md:rounded-2xl">
          {/* Toutes les photos sont superposées : le changement de coloris est un simple fondu. */}
          {product.variants.map((v) => (
            <div key={v.id} aria-hidden={v.id !== picked} className={`absolute inset-[8%] transition-opacity duration-(--dur-fast) ${v.id === picked ? '' : 'opacity-0'}`}>
              {v.images[0] && <Photo src={v.images[0].url} alt={v.images[0].alt} sizes="(min-width: 768px) 55vw, 90vw" />}
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-4.5 px-5 pt-5 pb-6 md:col-start-2 md:row-start-3 md:gap-7 md:px-8 md:py-0">
          <div className="flex items-baseline justify-between gap-3 md:border-t md:border-line-strong md:pt-6">
            <h3 className="text-card-title font-semibold">{variant.color_name}</h3>
            <p className="text-card-title font-medium">{euros(product.price_cents)}</p>
          </div>
          <Swatches variants={product.variants} selected={variant.id} onPick={(v) => setPicked(v.id)} />
          <Rarity stock={variant.stock} total={variant.stock_initial} />
          <Link href={`/casquette/${variant.color_slug}`} className={`btn ${variant.stock > 0 ? 'btn-primary' : 'btn-secondary'}`}>
            Voir {casquetteDeCouleur(variant.color_name)}
          </Link>
        </div>
      </div>
    </section>
  )
}
