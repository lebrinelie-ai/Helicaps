'use client'

import Link from 'next/link'
import { useState, useTransition } from 'react'
import { deleteProduct, saveProduct, uploadImage } from '@/app/admin/actions'
import type { Product, ProductInput } from '@/lib/types'
import { Icon, Photo } from './ui'

type VariantDraft = ProductInput['variants'][number] & { key: number }

const MAX_SIDE = 1600

/** Réduit une photo de téléphone avant l'envoi (plus rapide, et le site reste léger). */
async function shrink(file: File): Promise<File> {
  const bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' })
  const scale = Math.min(1, MAX_SIDE / Math.max(bitmap.width, bitmap.height))
  const canvas = Object.assign(document.createElement('canvas'), { width: Math.round(bitmap.width * scale), height: Math.round(bitmap.height * scale) })
  canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  // Un PNG peut avoir un fond transparent (casquette détourée) : on le garde tel quel.
  const type = file.type === 'image/png' ? 'image/png' : 'image/jpeg'
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, type, 0.85))
  if (!blob) throw new Error('conversion')
  return new File([blob], 'photo', { type })
}

function Field({ id, label, error, children }: { id: string; label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-caption text-text-secondary">
        {label}
      </label>
      {children}
      <p id={`${id}-erreur`} className="text-caption font-medium empty:hidden">
        {error}
      </p>
    </div>
  )
}

export function ProductForm({ product }: { product?: Product }) {
  const [name, setName] = useState(product?.name ?? '')
  const [price, setPrice] = useState(product ? String(product.price_cents / 100).replace('.', ',') : '')
  const [description, setDescription] = useState(product?.description ?? '')
  const [variants, setVariants] = useState<VariantDraft[]>(
    product?.variants.map((v, key) => ({
      key,
      id: v.id,
      color_name: v.color_name,
      swatch_hex: v.swatch_hex,
      stock: String(v.stock),
      images: v.images.map(({ url, kind }) => ({ url, kind })),
    })) ?? [{ key: 0, color_name: '', swatch_hex: '#1f1f1f', stock: '3', images: [] }],
  )
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [uploading, setUploading] = useState(0)
  const [pending, start] = useTransition()

  const update = (key: number, patch: Partial<VariantDraft>) => setVariants((list) => list.map((v) => (v.key === key ? { ...v, ...patch } : v)))
  const invalid = (field: string) => ({ 'aria-invalid': !!errors[field] || undefined, 'aria-describedby': `${field}-erreur` })

  async function addPhotos(variant: VariantDraft, i: number, files: File[]) {
    setUploading((n) => n + 1)
    let failed = ''
    for (const file of files) {
      try {
        const form = new FormData()
        form.set('file', await shrink(file))
        const result = await uploadImage(form)
        if ('error' in result) failed = result.error
        else setVariants((list) => list.map((v) => (v.key === variant.key ? { ...v, images: [...v.images, { url: result.url, kind: 'studio' }] } : v)))
      } catch {
        failed = 'Une photo n’a pas pu être envoyée. Réessayez.'
      }
    }
    setErrors((e) => ({ ...e, [`variants.${i}.images`]: failed }))
    setUploading((n) => n - 1)
  }

  function submit() {
    start(async () => {
      const result = await saveProduct({ id: product?.id, name, price, description, variants: variants.map(({ key: _, ...v }) => v) })
      setErrors(result)
      // Amène l'admin sur le premier champ à corriger.
      requestAnimationFrame(() => document.querySelector<HTMLElement>('[aria-invalid="true"], p[id$="-erreur"]:not(:empty)')?.scrollIntoView({ block: 'center' }))
    })
  }

  return (
    <form
      action={submit}
      className="flex flex-col gap-8"
      // Dès qu'un champ est corrigé, son message d'erreur disparaît.
      onChange={(e) => setErrors(({ [(e.target as HTMLElement).id]: _, ...rest }) => rest)}
    >
      <div className="flex flex-col gap-5">
        <Field id="name" label="Nom de la casquette" error={errors.name}>
          <input id="name" className="field" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} {...invalid('name')} />
        </Field>
        <Field id="price" label="Prix en euros" error={errors.price}>
          <input id="price" className="field" inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="90" {...invalid('price')} />
        </Field>
        <Field id="description" label="Description" error={errors.description}>
          <textarea id="description" className="field" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} {...invalid('description')} />
        </Field>
      </div>

      {variants.map((v, i) => (
        <fieldset key={v.key} className="flex flex-col gap-5 rounded-lg bg-surface p-5">
          <legend className="float-left text-card-title font-semibold">Coloris {i + 1}</legend>
          <Field id={`variants.${i}.color_name`} label="Nom du coloris" error={errors[`variants.${i}.color_name`]}>
            <input id={`variants.${i}.color_name`} className="field" value={v.color_name} onChange={(e) => update(v.key, { color_name: e.target.value })} placeholder="Bleu" maxLength={30} {...invalid(`variants.${i}.color_name`)} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field id={`variants.${i}.swatch_hex`} label="Couleur de la pastille" error={errors[`variants.${i}.swatch_hex`]}>
              <input id={`variants.${i}.swatch_hex`} type="color" className="field p-1.5" value={v.swatch_hex} onChange={(e) => update(v.key, { swatch_hex: e.target.value })} />
            </Field>
            <Field id={`variants.${i}.stock`} label="Nombre de pièces" error={errors[`variants.${i}.stock`]}>
              {/* Le stock d'un coloris déjà en vente se règle avec −/+ dans la liste des produits. */}
              <input id={`variants.${i}.stock`} className="field disabled:text-text-secondary" inputMode="numeric" value={v.stock} disabled={!!v.id} onChange={(e) => update(v.key, { stock: e.target.value })} {...invalid(`variants.${i}.stock`)} />
            </Field>
          </div>
          {v.id && <p className="-mt-3 text-caption text-text-secondary">Pour changer le stock, utilisez les boutons − et + dans la liste des produits.</p>}

          <div className="flex flex-col gap-3">
            <p className="text-caption text-text-secondary">Photos (la première est la photo principale)</p>
            <ul className="flex flex-col gap-2">
              {v.images.map((img, j) => {
                const move = (to: number) => {
                  const images = [...v.images]
                  images.splice(to, 0, images.splice(j, 1)[0])
                  update(v.key, { images })
                }
                return (
                  <li key={img.url} className="flex items-center gap-2 rounded-sm bg-surface-raised p-2">
                    <div className="stage-card relative size-14 flex-none overflow-hidden rounded-xs">
                      <Photo src={img.url} alt={`Photo ${j + 1}`} sizes="56px" className="object-cover" />
                    </div>
                    <label className="flex min-h-(--tap-min) flex-1 items-center gap-2 text-caption">
                      <input
                        type="checkbox"
                        className="size-5 accent-(--color-text)"
                        checked={img.kind === 'worn'}
                        onChange={(e) => update(v.key, { images: v.images.map((o, k) => (k === j ? { ...o, kind: e.target.checked ? 'worn' : 'studio' } : o)) })}
                      />
                      Photo portée
                    </label>
                    <button type="button" className="icon-btn" aria-label={`Monter la photo ${j + 1}`} disabled={j === 0} onClick={() => move(j - 1)}>
                      <Icon name="up" />
                    </button>
                    <button type="button" className="icon-btn" aria-label={`Descendre la photo ${j + 1}`} disabled={j === v.images.length - 1} onClick={() => move(j + 1)}>
                      <Icon name="down" />
                    </button>
                    <button type="button" className="icon-btn" aria-label={`Supprimer la photo ${j + 1}`} onClick={() => update(v.key, { images: v.images.filter((_, k) => k !== j) })}>
                      <Icon name="close" />
                    </button>
                  </li>
                )
              })}
            </ul>
            <label className="btn btn-secondary cursor-pointer">
              {uploading ? 'Envoi des photos…' : 'Ajouter des photos'}
              <input
                type="file"
                accept="image/*"
                multiple
                className="sr-only"
                onChange={(e) => {
                  // Copie de la liste : vider le champ juste après vide aussi la liste d'origine.
                  if (e.target.files?.length) addPhotos(v, i, [...e.target.files])
                  e.target.value = ''
                }}
              />
            </label>
            <p id={`variants.${i}.images-erreur`} role="alert" className="text-caption font-medium empty:hidden">
              {errors[`variants.${i}.images`]}
            </p>
          </div>

          {variants.length > 1 && (
            <button type="button" className="min-h-(--tap-min) self-start text-caption text-text-secondary underline" onClick={() => setVariants((list) => list.filter((o) => o.key !== v.key))}>
              Retirer ce coloris
            </button>
          )}
        </fieldset>
      ))}

      <p role="alert" className="text-caption font-medium empty:hidden">
        {errors.variants}
      </p>
      <button
        type="button"
        className="btn btn-secondary"
        onClick={() => setVariants((list) => [...list, { key: Math.max(...list.map((v) => v.key)) + 1, color_name: '', swatch_hex: '#1f1f1f', stock: '3', images: [] }])}
      >
        Ajouter un coloris
      </button>

      <div className="flex flex-col gap-3">
        <button type="submit" className="btn btn-primary" disabled={pending || uploading > 0}>
          {pending ? 'Enregistrement…' : product ? 'Enregistrer' : 'Publier'}
        </button>
        <Link href="/admin/produits" className="btn btn-secondary">
          Annuler
        </Link>
        {product && (
          <button
            type="button"
            className="min-h-(--tap-min) text-caption text-text-secondary underline"
            disabled={pending}
            onClick={() => confirm(`Supprimer définitivement « ${product.name} » ?`) && start(() => deleteProduct(product.id))}
          >
            Supprimer cette casquette
          </button>
        )}
      </div>
    </form>
  )
}
