'use client'

import Link from 'next/link'
import { createContext, use, useCallback, useEffect, useRef, useState } from 'react'
import { euros } from '@/lib/format'
import type { CartItem, Quote, Relay } from '@/lib/types'
import { RelayPicker } from './relay-picker'
import { Icon, Photo } from './ui'

const STORAGE_KEY = 'helicaps-panier'

type Cart = {
  items: CartItem[]
  quote: Quote | null
  count: number
  open: boolean
  setOpen: (open: boolean) => void
  /** Ajoute au panier et ouvre le tiroir. */
  add: (variantId: string, quantity: number) => void
  setQuantity: (variantId: string, quantity: number) => void
  clear: () => void
}

const CartContext = createContext<Cart | null>(null)

export function useCart() {
  const cart = use(CartContext)
  if (!cart) throw new Error('useCart doit être utilisé dans <CartProvider>')
  return cart
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [promo, setPromo] = useState('')
  const [relay, setRelay] = useState<Relay | null>(null)
  const [quote, setQuote] = useState<Quote | null>(null)
  const [open, setOpen] = useState(false)
  const [ready, setReady] = useState(false)

  // Le panier vit dans le navigateur : on le relit après le premier rendu pour ne pas contredire le HTML du serveur.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '{}')
      if (Array.isArray(saved.items)) setItems(saved.items)
      if (typeof saved.promo === 'string') setPromo(saved.promo)
      if (saved.relay) setRelay(saved.relay)
    } catch {}
    if (new URLSearchParams(location.search).has('panier')) setOpen(true) // retour depuis Stripe (paiement annulé)
    setReady(true)
  }, [])

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify({ items, promo, relay }))
  }, [ready, items, promo, relay])

  // Prix, stock et frais de port viennent toujours du serveur.
  const refresh = useCallback(async (nextItems: CartItem[], nextPromo: string, signal?: AbortSignal) => {
    const res = await fetch('/api/panier', { method: 'POST', body: JSON.stringify({ items: nextItems, promo: nextPromo }), signal })
    if (res.ok) apply(await res.json())
  }, [])

  function apply(next: Quote) {
    setQuote(next)
    // Le serveur a pu réduire une quantité ou retirer un article épuisé.
    setItems((current) => {
      const fixed = next.lines.map(({ variantId, quantity }) => ({ variantId, quantity }))
      return JSON.stringify(fixed) === JSON.stringify(current) ? current : fixed
    })
  }

  useEffect(() => {
    if (!ready) return
    const controller = new AbortController()
    refresh(items, promo, controller.signal).catch(() => {})
    return () => controller.abort()
  }, [ready, items, promo, refresh])

  const setQuantity = (variantId: string, quantity: number) =>
    setItems((current) =>
      quantity < 1 ? current.filter((i) => i.variantId !== variantId) : current.map((i) => (i.variantId === variantId ? { ...i, quantity } : i)),
    )

  const add = (variantId: string, quantity: number) => {
    setItems((current) =>
      current.some((i) => i.variantId === variantId)
        ? current.map((i) => (i.variantId === variantId ? { ...i, quantity: i.quantity + quantity } : i))
        : [...current, { variantId, quantity }],
    )
    setOpen(true)
  }

  const clear = useCallback(() => {
    // Appelé au chargement de la page « merci », avant la relecture ci-dessus : on efface aussi la sauvegarde.
    localStorage.removeItem(STORAGE_KEY)
    setItems([])
    setPromo('')
  }, [])

  const count = items.reduce((sum, i) => sum + i.quantity, 0)

  return (
    <CartContext value={{ items, quote, count, open, setOpen, add, setQuantity, clear }}>
      {children}
      <CartDrawer promo={promo} setPromo={setPromo} relay={relay} setRelay={setRelay} apply={apply} refresh={() => refresh(items, promo)} />
    </CartContext>
  )
}

export function CartButton() {
  const { count, setOpen } = useCart()
  return (
    <button type="button" className="icon-btn relative" aria-label={count ? `Ouvrir le panier, ${count} article${count > 1 ? 's' : ''}` : 'Ouvrir le panier, vide'} onClick={() => setOpen(true)}>
      <Icon name="bag" />
      {count > 0 && (
        <span aria-hidden="true" className="absolute top-1 right-0.5 flex h-4.5 min-w-4.5 items-center justify-center rounded-pill bg-text px-1 text-footnote leading-none font-semibold text-bg">
          {count}
        </span>
      )}
    </button>
  )
}

type DrawerProps = {
  promo: string
  setPromo: (code: string) => void
  relay: Relay | null
  setRelay: (relay: Relay | null) => void
  apply: (quote: Quote) => void
  refresh: () => Promise<void>
}

function CartDrawer({ promo, setPromo, relay, setRelay, apply, refresh }: DrawerProps) {
  const { items, quote, count, open, setOpen, setQuantity } = useCart()
  const dialog = useRef<HTMLDialogElement>(null)
  const [picking, setPicking] = useState(false)
  const [paying, setPaying] = useState(false)
  const [error, setError] = useState('')

  // <dialog> modal : focus piégé, Échap, voile et retour du focus au bouton panier sont gérés par le navigateur.
  useEffect(() => {
    const el = dialog.current!
    if (open && !el.open) el.showModal()
    if (!open && el.open) el.close()
    if (open) setError('')
  }, [open])

  async function pay() {
    setPaying(true)
    setError('')
    try {
      const res = await fetch('/api/paiement', { method: 'POST', body: JSON.stringify({ items, promo, relay }) })
      const data = await res.json()
      if (res.ok) return location.assign(data.url)
      setError(data.error ?? 'Le paiement est indisponible pour le moment.')
      if (data.quote) apply(data.quote)
      else await refresh()
    } catch {
      setError('Connexion impossible. Vérifiez votre réseau et réessayez.')
    }
    setPaying(false)
  }

  const lines = quote?.lines ?? []
  const empty = count === 0

  return (
    <dialog
      ref={dialog}
      className="drawer"
      aria-labelledby="panier-titre"
      onClose={() => {
        setOpen(false)
        setPicking(false)
      }}
      onClick={(e) => e.target === dialog.current && setOpen(false)}
    >
      <div className="flex h-full flex-col">
        <header className="flex h-(--nav-h) flex-none items-center justify-between border-b border-line-strong pr-1 pl-5">
          {picking ? (
            <button type="button" className="-ml-3 flex min-h-(--tap-min) items-center gap-1 pr-3 text-body" onClick={() => setPicking(false)}>
              <Icon name="back" /> Panier
            </button>
          ) : (
            <h2 id="panier-titre" className="text-body font-semibold">
              Panier ({count})
            </h2>
          )}
          {picking && (
            <h2 id="panier-titre" className="sr-only">
              Choisir un point relais
            </h2>
          )}
          <button type="button" className="icon-btn" aria-label="Fermer le panier" onClick={() => setOpen(false)}>
            <Icon name="close" />
          </button>
        </header>

        {picking ? (
          <RelayPicker
            defaultZip={relay?.zip}
            onPick={(picked) => {
              setRelay(picked)
              setPicking(false)
            }}
          />
        ) : empty ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-6 px-6 text-center">
            <p className="text-card-title font-semibold">Votre panier est vide</p>
            <Link href="/#coloris" className="btn btn-primary" onClick={() => setOpen(false)}>
              Voir les coloris
            </Link>
          </div>
        ) : (
          <>
            <div className="flex flex-1 flex-col gap-6 overflow-y-auto px-5 py-5">
              <ul className="flex flex-col gap-5">
                {lines.map((line) => (
                  <li key={line.variantId} className="flex gap-4">
                    <div className="stage-card relative size-22 flex-none overflow-hidden rounded-sm">
                      {line.image && <Photo src={line.image} alt="" sizes="88px" />}
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col gap-1">
                      <div className="flex justify-between gap-3">
                        <p className="font-semibold">
                          {line.product_name}, {line.color_name}
                        </p>
                        <p className="whitespace-nowrap">{euros(line.unit_price_cents * line.quantity, true)}</p>
                      </div>
                      <p className="text-caption text-text-secondary">Taille M</p>
                      <div className="mt-1 flex items-center justify-between">
                        <div className="flex items-center rounded-pill bg-surface-raised">
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={`Retirer une ${line.product_name}, ${line.color_name}`}
                            onClick={() => setQuantity(line.variantId, line.quantity - 1)}
                          >
                            <Icon name="minus" size={18} />
                          </button>
                          <span className="min-w-6 text-center font-medium" aria-live="polite">
                            <span className="sr-only">Quantité : </span>
                            {line.quantity}
                          </span>
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={`Ajouter une ${line.product_name}, ${line.color_name}`}
                            disabled={line.quantity >= line.stock}
                            onClick={() => setQuantity(line.variantId, line.quantity + 1)}
                          >
                            <Icon name="plus" size={18} />
                          </button>
                        </div>
                        <button type="button" className="min-h-(--tap-min) px-2 text-caption text-text-secondary underline" onClick={() => setQuantity(line.variantId, 0)}>
                          Retirer
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>

              {quote && <FreeShipping quote={quote} />}
              <PromoForm promo={promo} setPromo={setPromo} quote={quote} />

              <section aria-labelledby="relais-titre" className="flex flex-col gap-2">
                <h3 id="relais-titre" className="text-caption text-text-secondary">
                  Point relais Mondial Relay
                </h3>
                {relay ? (
                  <div className="flex items-start justify-between gap-3 rounded-sm bg-surface-raised py-3 pr-2 pl-4">
                    <p className="text-caption">
                      <span className="block text-body font-semibold">{relay.name}</span>
                      {relay.address}
                      <br />
                      {relay.zip} {relay.city}
                    </p>
                    <button type="button" className="min-h-(--tap-min) px-2 text-caption underline" onClick={() => setPicking(true)}>
                      Modifier
                    </button>
                  </div>
                ) : (
                  <button type="button" className="flex min-h-14 items-center gap-3 rounded-sm bg-surface-raised px-4 text-left" onClick={() => setPicking(true)}>
                    <Icon name="pin" />
                    <span className="flex-1">Choisir un point relais</span>
                    <Icon name="chevron" size={18} />
                  </button>
                )}
              </section>
            </div>

            <footer className="flex flex-none flex-col gap-4 border-t border-line-strong px-5 pt-4 pb-[calc(var(--space-4)+env(safe-area-inset-bottom))]">
              {quote && (
                <dl className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-1 text-caption text-text-secondary">
                  <dt>Sous-total</dt>
                  <dd className="text-right">{euros(quote.subtotal_cents, true)}</dd>
                  <dt>Livraison en point relais</dt>
                  <dd className="text-right">{quote.shipping_cents ? euros(quote.shipping_cents, true) : 'Offerte'}</dd>
                  {quote.discount_cents > 0 && (
                    <>
                      <dt>Réduction</dt>
                      <dd className="text-right">−{euros(quote.discount_cents, true)}</dd>
                    </>
                  )}
                  <dt className="pt-2 text-body font-semibold text-text">Total</dt>
                  <dd className="pt-2 text-right text-body font-semibold text-text">{euros(quote.total_cents, true)}</dd>
                </dl>
              )}
              <p role="alert" className="text-caption font-medium empty:hidden">
                {error}
              </p>
              {!relay && <p className="text-caption text-text-secondary">Choisissez un point relais pour payer.</p>}
              <button type="button" className="btn btn-primary" disabled={!relay || !quote || paying} onClick={pay}>
                {paying ? 'Redirection vers le paiement…' : `Payer ${quote ? euros(quote.total_cents, true) : ''}`}
              </button>
            </footer>
          </>
        )}
      </div>
    </dialog>
  )
}

function FreeShipping({ quote }: { quote: Quote }) {
  const missing = quote.free_shipping_missing_cents
  const goal = quote.subtotal_cents - quote.discount_cents + missing
  return (
    <div className="flex flex-col gap-2">
      <p className="text-caption font-medium">{missing > 0 ? `Plus que ${euros(missing)} pour la livraison offerte` : 'Livraison offerte'}</p>
      <div className="h-1 overflow-hidden rounded-pill bg-inactive" aria-hidden="true">
        <div className="h-full rounded-pill bg-accent" style={{ width: `${Math.round(((goal - missing) / goal) * 100)}%` }} />
      </div>
    </div>
  )
}

function PromoForm({ promo, setPromo, quote }: { promo: string; setPromo: (code: string) => void; quote: Quote | null }) {
  const [draft, setDraft] = useState(promo)
  useEffect(() => setDraft(promo), [promo])
  const status = quote?.promo?.code === promo ? quote.promo : null

  return (
    <form
      className="flex flex-col gap-2"
      onSubmit={(e) => {
        e.preventDefault()
        setPromo(draft.trim())
      }}
    >
      <label htmlFor="code-promo" className="text-caption text-text-secondary">
        Code promo
      </label>
      <div className="flex gap-2">
        <input
          id="code-promo"
          className="field min-w-0 flex-1 uppercase"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          autoComplete="off"
          autoCapitalize="characters"
          spellCheck={false}
          maxLength={40}
          aria-describedby="code-promo-etat"
          aria-invalid={status ? !status.valid : undefined}
        />
        <button type="submit" className="btn btn-secondary px-5">
          Appliquer
        </button>
      </div>
      <p id="code-promo-etat" role="status" className="text-caption font-medium empty:hidden">
        {status && (status.valid ? `Code ${status.code.toUpperCase()} appliqué` : 'Ce code n’existe pas ou a expiré')}
      </p>
    </form>
  )
}
