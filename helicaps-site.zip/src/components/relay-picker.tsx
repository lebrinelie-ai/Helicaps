'use client'

import { useEffect, useRef, useState } from 'react'
import type { Relay } from '@/lib/types'

const text = (value: unknown, max: number) => (typeof value === 'string' && value.length > 0 && value.length <= max ? value : null)

/**
 * Affiche le widget Mondial Relay dans un cadre fermé (voir src/app/relais/route.ts).
 * `sandbox="allow-scripts"` sans « allow-same-origin » : le widget tourne, mais il est traité comme un site
 * étranger. Il ne peut ni lire cette page ni agir dessus ; il nous envoie seulement le point relais choisi.
 */
export function RelayPicker({ defaultZip, onPick }: { defaultZip?: string; onPick: (relay: Relay) => void }) {
  const frame = useRef<HTMLIFrameElement>(null)
  const [picked, setPicked] = useState<Relay | null>(null)

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      // On n'écoute que notre cadre, et on revérifie chaque champ : rien de ce qui en sort n'est cru sur parole.
      if (event.source !== frame.current?.contentWindow || event.data?.type !== 'helicaps-relais') return
      const r = event.data.relay ?? {}
      const relay = { id: text(r.id, 12), name: text(r.name, 80), address: text(r.address, 160), zip: text(r.zip, 10), city: text(r.city, 80) }
      if (Object.values(relay).every(Boolean)) setPicked(relay as Relay)
    }
    window.addEventListener('message', onMessage)
    return () => window.removeEventListener('message', onMessage)
  }, [])

  return (
    <>
      <iframe
        ref={frame}
        src={`/relais${defaultZip && /^\d{5}$/.test(defaultZip) ? `?cp=${defaultZip}` : ''}`}
        title="Choix du point relais Mondial Relay"
        sandbox="allow-scripts"
        referrerPolicy="no-referrer"
        className="w-full flex-1 bg-text"
      />
      <footer className="flex flex-none flex-col gap-3 border-t border-line-strong px-5 pt-4 pb-[calc(var(--space-4)+env(safe-area-inset-bottom))]">
        <p className="text-caption" aria-live="polite">
          {picked ? (
            <>
              <span className="block text-body font-semibold">{picked.name}</span>
              {picked.address}, {picked.zip} {picked.city}
            </>
          ) : (
            <span className="text-text-secondary">Saisissez votre code postal, puis touchez un point relais dans la liste.</span>
          )}
        </p>
        <button type="button" className="btn btn-primary" disabled={!picked} onClick={() => picked && onPick(picked)}>
          Choisir ce point relais
        </button>
      </footer>
    </>
  )
}
