'use client'

import Link from 'next/link'
import { useRef } from 'react'
import { Icon } from './ui'

export function MobileMenu({ liens }: { liens: { href: string; label: string }[] }) {
  const dialog = useRef<HTMLDialogElement>(null)
  const close = () => dialog.current?.close()

  return (
    <div className="md:hidden">
      <button type="button" className="icon-btn" aria-label="Ouvrir le menu" onClick={() => dialog.current?.showModal()}>
        <Icon name="menu" />
      </button>
      <dialog ref={dialog} className="drawer drawer-left" aria-label="Menu" onClick={(e) => e.target === dialog.current && close()}>
        <div className="flex h-(--nav-h) items-center border-b border-line-strong px-1">
          <button type="button" className="icon-btn" aria-label="Fermer le menu" onClick={close}>
            <Icon name="close" />
          </button>
        </div>
        <nav aria-label="Navigation principale">
          <ul className="px-5 py-3">
            {liens.map((l) => (
              <li key={l.label} className="border-b border-line-strong last:border-0">
                <Link href={l.href} className="flex min-h-15 items-center justify-between text-card-title font-semibold" onClick={close}>
                  {l.label}
                  <Icon name="chevron" size={18} />
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </dialog>
    </div>
  )
}
