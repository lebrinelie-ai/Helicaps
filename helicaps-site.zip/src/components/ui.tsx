import Image from 'next/image'
import { stockLabel } from '@/lib/format'
import { TAILLE } from '@/lib/content'
import type { Variant } from '@/lib/types'

// Tracés repris tels quels des maquettes (trait 1,75, bouts arrondis).
const PATHS = {
  menu: <path d="M4 9h16M4 15h16" />,
  bag: (
    <>
      <path d="M5 8h14l-1 12H6L5 8z" />
      <path d="M9 8V6a3 3 0 0 1 6 0v2" />
    </>
  ),
  close: <path d="M6 6l12 12M18 6L6 18" />,
  chevron: <path d="M9 6l6 6-6 6" />,
  back: <path d="M15 6l-6 6 6 6" />,
  minus: <path d="M6 12h12" />,
  plus: <path d="M12 6v12M6 12h12" />,
  up: <path d="M6 15l6-6 6 6" />,
  down: <path d="M6 9l6 6 6-6" />,
  pin: (
    <>
      <path d="M12 21s-6.5-5.8-6.5-11a6.5 6.5 0 0 1 13 0c0 5.2-6.5 11-6.5 11z" />
      <circle cx="12" cy="10" r="2.4" />
    </>
  ),
  box: (
    <>
      <path d="M3.5 7.5 12 3.2l8.5 4.3v9L12 20.8l-8.5-4.3v-9z" />
      <path d="M3.5 7.5 12 11.8l8.5-4.3M12 11.8v9" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10.5" width="14" height="10" rx="2" />
      <path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  instagram: (
    <>
      <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="0.6" fill="currentColor" />
    </>
  ),
  tiktok: (
    <>
      <path d="M14 3.5v11a3.5 3.5 0 1 1-3.5-3.5" />
      <path d="M14 3.5c.4 2.6 2.2 4.4 5 4.6" />
    </>
  ),
  tag: (
    <>
      <path d="M3.5 12.5v-8h8l9 9-8 8-9-9z" />
      <circle cx="8" cy="9" r="1.2" />
    </>
  ),
}

export type IconName = keyof typeof PATHS

export function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {PATHS[name]}
    </svg>
  )
}

/** Photo qui remplit son parent (qui doit être `relative`). Les visuels provisoires en SVG ne passent pas par l'optimiseur. */
export function Photo({ src, alt, sizes, preload, className = 'object-contain' }: { src: string; alt: string; sizes: string; preload?: boolean; className?: string }) {
  return <Image src={src} alt={alt} fill sizes={sizes} preload={preload} loading={preload ? 'eager' : undefined} unoptimized={src.endsWith('.svg')} className={className} />
}

/** Indicateur de rareté : un segment par pièce fabriquée, et toujours le texte à côté. */
export function Rarity({ stock, total, showSize = true }: { stock: number; total: number; showSize?: boolean }) {
  return (
    <div className="flex flex-col gap-2.5">
      <div aria-hidden="true" className="flex gap-1">
        {Array.from({ length: Math.max(total, stock, 1) }, (_, i) => (
          <span key={i} className={`h-1 flex-1 rounded-pill ${i < stock ? 'bg-accent' : 'bg-inactive'}`} />
        ))}
      </div>
      <div className="flex justify-between gap-3 text-caption">
        <p className={stock > 0 ? 'font-semibold text-accent' : 'text-text-secondary'}>{stockLabel(stock)}</p>
        {showSize && <p className="text-text-secondary">{TAILLE}</p>}
      </div>
    </div>
  )
}

/** Pastilles de coloris : rondes sur mobile, avec le nom sur desktop. Barrées quand le coloris est épuisé. */
export function Swatches({ variants, selected, onPick }: { variants: Variant[]; selected: string; onPick: (variant: Variant) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {variants.map((v) => (
        <button
          key={v.id}
          type="button"
          aria-pressed={v.id === selected}
          onClick={() => onPick(v)}
          className={`flex size-(--swatch-size) items-center justify-center rounded-pill border-2 p-1 text-caption font-medium md:h-12 md:w-auto md:justify-start md:gap-2.5 md:bg-surface-pill md:py-1 md:pr-4.5 md:pl-1.5 ${
            v.id === selected ? 'border-text' : 'border-transparent md:border-surface-pill'
          }`}
        >
          <span aria-hidden="true" className="relative size-8 flex-none overflow-hidden rounded-pill" style={{ background: v.swatch_hex, boxShadow: 'var(--swatch-inner-ring)' }}>
            {v.stock < 1 && <span className="absolute top-1/2 -left-1 h-0.5 w-10 -translate-y-1/2 -rotate-45 bg-text" />}
          </span>
          <span className="max-md:sr-only">
            {v.color_name}
            {v.stock < 1 && <span className="sr-only">, épuisé</span>}
          </span>
        </button>
      ))}
    </div>
  )
}
