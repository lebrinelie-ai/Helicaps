import Link from 'next/link'
import { AVIS, LIENS_PIED, RESEAUX, SITE } from '@/lib/content'
import { CartButton } from './cart'
import { MobileMenu } from './mobile-menu'
import { Icon } from './ui'

// Liens de la barre : « Avis » n'apparaît que s'il y a de vrais avis.
const LIENS = [
  { href: '/#coloris', label: 'Coloris' },
  ...(AVIS.length ? [{ href: '/#avis', label: 'Avis' }] : []),
  { href: '/#livraison', label: 'Livraison' },
]

export function Nav() {
  return (
    <header className="sticky top-0 z-20 h-(--nav-h) border-b border-nav-border bg-nav-bg backdrop-blur-[20px] backdrop-saturate-[1.8]">
      <div className="mx-auto flex h-full max-w-(--page-max) items-center justify-between px-1 md:px-(--page-gutter)">
        <div className="flex flex-1">
          <MobileMenu liens={[...LIENS, ...RESEAUX.map((r) => ({ href: r.url, label: r.name }))]} />
          <nav aria-label="Navigation principale" className="flex gap-1 max-md:hidden">
            {LIENS.map((l) => (
              <Link key={l.href} href={l.href} className="flex min-h-(--tap-min) items-center px-3 text-caption">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
        <Link href="/" aria-label={`${SITE.name}, accueil`} className="logo">
          HELICAPS
        </Link>
        <div className="flex flex-1 items-center justify-end gap-1">
          {RESEAUX.map((r) => (
            <a key={r.id} href={r.url} aria-label={`${SITE.name} sur ${r.name}`} className="icon-btn max-md:hidden">
              <Icon name={r.id} size={20} />
            </a>
          ))}
          <CartButton />
        </div>
      </div>
    </header>
  )
}

export function Footer() {
  return (
    <footer className="mt-18 flex flex-col items-center gap-6 border-t border-line px-6 py-10 text-center">
      <p className="logo min-h-0">HELICAPS</p>
      <nav aria-label="Informations" className="w-full max-w-180">
        <ul className="grid grid-cols-2 gap-x-3 md:flex md:flex-wrap md:justify-center md:gap-x-6">
          {LIENS_PIED.map((l) => (
            <li key={l.href} className="max-md:last:col-span-2">
              <Link href={l.href} className="flex min-h-(--tap-min) items-center justify-center text-caption text-text-secondary">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <p className="text-footnote text-text-secondary">
        © {new Date().getFullYear()} {SITE.name}. {SITE.tagline}
      </p>
    </footer>
  )
}
