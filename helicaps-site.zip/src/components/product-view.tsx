'use client'

import { useRef, useState } from 'react'
import { INFOS_PRODUIT, SITE, TAILLE } from '@/lib/content'
import { euros } from '@/lib/format'
import type { Product, Variant } from '@/lib/types'
import { useCart } from './cart'
import { Icon, Photo, Rarity, Swatches } from './ui'

export function ProductView({ product, initial }: { product: Product; initial: string }) {
  const cart = useCart()
  const [slug, setSlug] = useState(initial)
  const [wanted, setWanted] = useState(1)
  const variant = product.variants.find((v) => v.color_slug === slug) ?? product.variants[0]

  // Quantité max = stock restant, moins ce qui est déjà dans le panier.
  const inCart = cart.items.find((i) => i.variantId === variant.id)?.quantity ?? 0
  const max = Math.max(0, variant.stock - inCart)
  const quantity = Math.min(wanted, Math.max(max, 1))
  const label = variant.stock < 1 ? 'Épuisé' : max < 1 ? 'Déjà dans votre panier' : 'Ajouter au panier'

  function pick(v: Variant) {
    setSlug(v.color_slug)
    setWanted(1)
    // Change l'adresse sans recharger la page.
    window.history.replaceState(null, '', `/casquette/${v.color_slug}`)
    document.title = `${product.name}, ${v.color_name.toLowerCase()} · ${SITE.name}`
  }

  return (
    <article className="mx-auto flex max-w-(--page-max) flex-col md:grid md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] md:items-start md:gap-x-12 md:px-(--page-gutter) md:pt-8">
      <Gallery key={variant.id} variant={variant} />

      <div className="flex flex-col gap-6 px-5 pt-6 md:sticky md:top-[calc(var(--nav-h)+var(--space-8))] md:col-start-2 md:px-0 md:pt-0">
        <div className="flex flex-col gap-3">
          <h1 className="text-title font-semibold">
            {product.name}, <span className="whitespace-nowrap">{variant.color_name.toLowerCase()}</span>
          </h1>
          <div className="flex items-center gap-3">
            <p className="text-card-title font-medium">{euros(product.price_cents)}</p>
            <span className="rounded-pill bg-surface-raised px-3 py-1 text-caption text-text-secondary">{TAILLE}</span>
          </div>
        </div>

        <Swatches variants={product.variants} selected={variant.id} onPick={pick} />
        <Rarity stock={variant.stock} total={variant.stock_initial} showSize={false} />

        {max > 1 && (
          <div className="flex items-center justify-between">
            <span id="quantite" className="text-caption text-text-secondary">
              Quantité
            </span>
            <div role="group" aria-labelledby="quantite" className="flex items-center rounded-pill bg-surface-raised">
              <button type="button" className="icon-btn" aria-label="Diminuer la quantité" disabled={quantity <= 1} onClick={() => setWanted(quantity - 1)}>
                <Icon name="minus" size={18} />
              </button>
              <span className="min-w-6 text-center font-medium" aria-live="polite">
                {quantity}
              </span>
              <button type="button" className="icon-btn" aria-label="Augmenter la quantité" disabled={quantity >= max} onClick={() => setWanted(quantity + 1)}>
                <Icon name="plus" size={18} />
              </button>
            </div>
          </div>
        )}

        {/* Sur mobile, l'action principale reste collée en bas de l'écran, à portée de pouce. */}
        <div data-buy-bar className="z-10 flex items-center gap-4 border-nav-border bg-nav-bg max-md:fixed max-md:inset-x-0 max-md:bottom-0 max-md:border-t max-md:px-4 max-md:pt-3 max-md:pb-[calc(var(--space-3)+env(safe-area-inset-bottom))] max-md:backdrop-blur-[20px] max-md:backdrop-saturate-[1.8] md:bg-transparent">
          <p className="font-semibold md:hidden">{euros(product.price_cents)}</p>
          <button
            type="button"
            className="btn btn-primary flex-1"
            disabled={max < 1}
            onClick={() => {
              cart.add(variant.id, quantity)
              setWanted(1)
            }}
          >
            {label}
          </button>
        </div>

        {product.description && <p className="whitespace-pre-line text-text-secondary">{product.description}</p>}

        <div className="border-t border-line-strong">
          {INFOS_PRODUIT.map((info) => (
            <details key={info.titre} className="group border-b border-line-strong">
              <summary className="flex min-h-14 list-none items-center justify-between font-medium [&::-webkit-details-marker]:hidden">
                {info.titre}
                <span className="transition-transform duration-(--dur-fast) group-open:rotate-90">
                  <Icon name="chevron" size={18} />
                </span>
              </summary>
              <p className="pb-5 text-caption text-text-secondary">{info.texte}</p>
            </details>
          ))}
        </div>
      </div>
    </article>
  )
}

/** Galerie à faire glisser : photos studio puis portées du coloris choisi. */
function Gallery({ variant }: { variant: Variant }) {
  const list = useRef<HTMLUListElement>(null)
  const [index, setIndex] = useState(0)
  const images = variant.images
  const go = (step: number) => list.current?.scrollBy({ left: step * list.current.clientWidth })

  return (
    <div className="fade-in relative md:col-start-1 md:row-start-1">
      <ul
        ref={list}
        aria-label={`Photos, coloris ${variant.color_name.toLowerCase()}`}
        className="flex snap-x snap-mandatory overflow-x-auto [scrollbar-width:none] motion-safe:scroll-smooth md:rounded-2xl"
        onScroll={(e) => setIndex(Math.round(e.currentTarget.scrollLeft / e.currentTarget.clientWidth))}
      >
        {images.map((img, i) => (
          <li key={img.id} className="stage-card relative aspect-[4/3] w-full flex-none snap-center">
            {/* Studio : la casquette entière sur la scène. Portée : la photo remplit le cadre. */}
            <div className={`absolute ${img.kind === 'worn' ? 'inset-0' : 'inset-[8%]'}`}>
              <Photo src={img.url} alt={img.alt} sizes="(min-width: 768px) 55vw, 100vw" preload={i === 0} className={img.kind === 'worn' ? 'object-cover' : 'object-contain'} />
            </div>
          </li>
        ))}
      </ul>

      {images.length > 1 && (
        <>
          <div className="pointer-events-none absolute inset-y-0 right-4 left-4 flex items-center justify-between max-md:hidden">
            <button type="button" className="icon-btn pointer-events-auto bg-nav-bg" aria-label="Photo précédente" disabled={index === 0} onClick={() => go(-1)}>
              <Icon name="back" />
            </button>
            <button type="button" className="icon-btn pointer-events-auto bg-nav-bg" aria-label="Photo suivante" disabled={index === images.length - 1} onClick={() => go(1)}>
              <Icon name="chevron" />
            </button>
          </div>
          <p className="sr-only" aria-live="polite">
            Photo {index + 1} sur {images.length}
          </p>
          <div aria-hidden="true" className="absolute inset-x-0 bottom-4 flex justify-center gap-2">
            {images.map((img, i) => (
              <span key={img.id} className={`size-2 rounded-pill ${i === index ? 'bg-text' : 'bg-inactive'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
