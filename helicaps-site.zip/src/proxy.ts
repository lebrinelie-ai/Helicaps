import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

// Deux rôles, à chaque page demandée :
// 1. poser la Content-Security-Policy, avec un jeton (« nonce ») tiré au hasard pour cette seule réponse ;
// 2. sur /admin, garder la session Supabase à jour (les pages ne peuvent pas réécrire les cookies).
// Ce n'est pas le contrôle d'accès : celui-ci est dans requireAdmin() (src/lib/auth.ts).

const dev = process.env.NODE_ENV === 'development'
const supabaseOrigin = process.env.NEXT_PUBLIC_SUPABASE_URL ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).origin : ''

/**
 * Seuls nos scripts (porteurs du nonce) et ceux qu'ils chargent eux-mêmes peuvent s'exécuter :
 * un script injecté dans la page par un attaquant est refusé par le navigateur.
 * Aucun domaine extérieur n'est autorisé, sauf le stockage des photos. Le widget Mondial Relay,
 * qui a besoin de plus, est enfermé dans un cadre à part (src/app/relais/route.ts).
 */
function contentSecurityPolicy(nonce: string) {
  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${dev ? " 'unsafe-eval'" : ''}`,
    "style-src 'self' 'unsafe-inline'",
    `img-src 'self' data: ${supabaseOrigin}`.trim(),
    "font-src 'self'",
    `connect-src 'self'${dev ? ' ws:' : ''}`,
    "frame-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; ')
}

export async function proxy(request: NextRequest) {
  const nonce = btoa(crypto.randomUUID())
  const csp = contentSecurityPolicy(nonce)

  // Next.js lit la politique dans les en-têtes de la requête pour mettre le nonce sur ses propres scripts.
  const requestHeaders = new Headers(request.headers)
  requestHeaders.set('x-nonce', nonce)
  requestHeaders.set('Content-Security-Policy', csp)
  const next = () => {
    const res = NextResponse.next({ request: { headers: requestHeaders } })
    res.headers.set('Content-Security-Policy', csp)
    return res
  }
  let response = next()

  if (request.nextUrl.pathname.startsWith('/admin') && process.env.NEXT_PUBLIC_SUPABASE_URL) {
    const client = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!, {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (list, cacheHeaders) => {
          // La page qui va être rendue doit voir la session rafraîchie, et le navigateur doit la recevoir.
          for (const { name, value } of list) request.cookies.set(name, value)
          requestHeaders.set('cookie', request.cookies.toString())
          response = next()
          for (const { name, value, options } of list) {
            // httpOnly : un script dans la page ne peut pas lire le cookie de session.
            response.cookies.set(name, value, { ...options, httpOnly: true, secure: !dev, sameSite: 'lax' })
          }
          for (const [key, value] of Object.entries(cacheHeaders)) response.headers.set(key, value)
        },
      },
    })
    await client.auth.getUser()
  }
  return response
}

export const config = {
  matcher: [
    {
      // Toutes les pages, sauf les fichiers statiques et les routes /api (qui ne renvoient pas de HTML).
      source: '/((?!api|relais|_next/static|_next/image|images|uploads|icon.svg|favicon.ico|robots.txt|sitemap.xml|opengraph-image).*)',
      missing: [
        { type: 'header', key: 'next-router-prefetch' },
        { type: 'header', key: 'purpose', value: 'prefetch' },
      ],
    },
  ],
}
