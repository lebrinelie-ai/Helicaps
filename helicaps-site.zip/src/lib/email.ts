import 'server-only'
import { SITE } from './content'
import type { Order } from './types'

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`)

/** E-mail « Commande expédiée » via Resend. Renvoie false s'il n'a pas pu partir. */
export async function sendShippedEmail(order: Order): Promise<boolean> {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM || !order.email) return false
  const items = order.items.map((i) => `<li>${esc(i.product_name)}, ${esc(i.color_name)} × ${i.quantity}</li>`).join('')
  const tracking = order.tracking_number
    ? `<p>Numéro de suivi Mondial Relay : <strong>${esc(order.tracking_number)}</strong></p>`
    : ''
  const html = `
    <p>Bonjour ${esc(order.customer_name)},</p>
    <p>Votre commande ${esc(order.number)} vient d’être expédiée.</p>
    <ul>${items}</ul>
    <p>Elle vous attendra dans votre point relais :<br>
    ${esc(order.relay_name)}<br>${esc(order.relay_address)}<br>${esc(order.relay_zip)} ${esc(order.relay_city)}</p>
    ${tracking}
    <p>Mondial Relay vous préviendra dès que le colis sera disponible.</p>
    <p>Merci,<br>${SITE.name}</p>`

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM,
      to: order.email,
      subject: `Votre commande ${order.number} est expédiée`,
      html,
    }),
  })
  if (!res.ok) console.error('Resend :', res.status, await res.text())
  return res.ok
}
