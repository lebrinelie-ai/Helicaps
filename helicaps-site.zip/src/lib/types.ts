export type ProductImage = {
  id: string
  url: string
  alt: string
  kind: 'studio' | 'worn'
  sort_order: number
}

export type Variant = {
  id: string
  product_id: string
  color_name: string
  color_slug: string
  swatch_hex: string
  /** Pièces encore en vente (les réservations en cours de paiement sont déjà déduites). */
  stock: number
  /** Pièces fabriquées : le « sur 9 » et le nombre de segments de l'indicateur de rareté. */
  stock_initial: number
  sort_order: number
  images: ProductImage[]
}

export type Product = {
  id: string
  name: string
  slug: string
  description: string
  price_cents: number
  is_active: boolean
  created_at: string
  variants: Variant[]
}

export type Relay = { id: string; name: string; address: string; zip: string; city: string }

export type OrderItem = {
  variant_id: string | null
  product_name: string
  color_name: string
  quantity: number
  unit_price_cents: number
}

export type Order = {
  id: string
  number: string
  stripe_session_id: string
  email: string
  customer_name: string
  phone: string
  relay_id: string
  relay_name: string
  relay_address: string
  relay_zip: string
  relay_city: string
  subtotal_cents: number
  shipping_cents: number
  discount_cents: number
  total_cents: number
  status: 'paid' | 'shipped' | 'cancelled'
  tracking_number: string | null
  shipped_at: string | null
  created_at: string
  items: OrderItem[]
}

export type NewOrder = Pick<
  Order,
  | 'stripe_session_id'
  | 'email'
  | 'customer_name'
  | 'phone'
  | 'relay_id'
  | 'relay_name'
  | 'relay_address'
  | 'relay_zip'
  | 'relay_city'
  | 'subtotal_cents'
  | 'shipping_cents'
  | 'discount_cents'
  | 'total_cents'
>

export type ReservationItem = { variant_id: string; quantity: number; unit_price_cents: number }

/** Ce que le formulaire admin envoie. Le stock n'est lu que pour un nouveau coloris. */
export type ProductInput = {
  id?: string
  name: string
  price: string
  description: string
  variants: {
    id?: string
    color_name: string
    swatch_hex: string
    stock: string
    images: { url: string; kind: 'studio' | 'worn' }[]
  }[]
}

export type CartItem = { variantId: string; quantity: number }

export type CartLine = CartItem & {
  product_name: string
  color_name: string
  color_slug: string
  image: string | null
  unit_price_cents: number
  stock: number
}

export type Quote = {
  lines: CartLine[]
  subtotal_cents: number
  discount_cents: number
  shipping_cents: number
  total_cents: number
  free_shipping_missing_cents: number
  /** null = pas de code saisi. */
  promo: { code: string; valid: boolean } | null
}
