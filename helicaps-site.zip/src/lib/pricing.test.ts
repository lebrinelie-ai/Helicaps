import assert from 'node:assert/strict'
import { test } from 'node:test'
import { parseEuros } from './format.ts'
import { totals } from './pricing.ts'

test('une casquette : 90 € + 3 € de port', () => {
  assert.deepEqual(totals(9000), {
    subtotal_cents: 9000,
    discount_cents: 0,
    shipping_cents: 300,
    total_cents: 9300,
    free_shipping_missing_cents: 9000,
  })
})

test('deux casquettes : livraison offerte dès 180 €', () => {
  const t = totals(18000)
  assert.equal(t.shipping_cents, 0)
  assert.equal(t.total_cents, 18000)
  assert.equal(t.free_shipping_missing_cents, 0)
})

test('le seuil de livraison offerte se juge après réduction', () => {
  const t = totals(18000, { percent_off: 10, amount_off: null })
  assert.equal(t.discount_cents, 1800)
  assert.equal(t.shipping_cents, 300)
  assert.equal(t.total_cents, 16500)
})

test('une réduction ne dépasse jamais le sous-total', () => {
  const t = totals(9000, { percent_off: null, amount_off: 20000 })
  assert.equal(t.discount_cents, 9000)
  assert.equal(t.total_cents, 300)
})

test('saisie du prix dans l’admin', () => {
  assert.equal(parseEuros('90'), 9000)
  assert.equal(parseEuros('89,9'), 8990)
  assert.equal(parseEuros(' 89.90 € '), 8990)
  assert.equal(parseEuros('gratuit'), null)
  assert.equal(parseEuros('-5'), null)
})
