/** « 90 € » par défaut, « 93,00 € » avec `decimals` (panier, totaux). */
export function euros(cents: number, decimals = cents % 100 !== 0) {
  const digits = decimals ? 2 : 0
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(cents / 100)
}

/** « 90 », « 89,90 », « 89.9 » → centimes. null si ce n'est pas un prix. */
export function parseEuros(input: string): number | null {
  const m = /^(\d{1,5})(?:[.,](\d{1,2}))?$/.exec(input.trim().replace(/\s|€/g, ''))
  if (!m) return null
  return Number(m[1]) * 100 + Number((m[2] ?? '').padEnd(2, '0'))
}

/** Texte de rareté, toujours affiché à côté des segments. */
export function stockLabel(stock: number) {
  if (stock <= 0) return 'Épuisé'
  if (stock === 1) return 'Dernière pièce'
  return `Plus que ${stock} pièces`
}

const MOTS = [
  'zéro', 'une', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix',
  'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf', 'vingt',
]

/** « Trois coloris », « Neuf pièces » : en lettres jusqu'à vingt (accordé au féminin si `feminine`). */
export function compter(n: number, singular: string, plural = singular + 's', feminine = true) {
  const mot = n === 1 && !feminine ? 'un' : (MOTS[n] ?? String(n))
  return `${mot.charAt(0).toUpperCase()}${mot.slice(1)} ${n > 1 ? plural : singular}`
}

const FEMININ: Record<string, string> = {
  noir: 'noire', bleu: 'bleue', vert: 'verte', blanc: 'blanche', gris: 'grise', violet: 'violette',
  brun: 'brune', rouge: 'rouge', jaune: 'jaune', rose: 'rose', beige: 'beige', orange: 'orange',
  marron: 'marron', kaki: 'kaki', bordeaux: 'bordeaux',
}

/** « la casquette bleue » quand on sait accorder la couleur, sinon « le coloris Sable ». */
export function casquetteDeCouleur(colorName: string) {
  const adj = FEMININ[colorName.trim().toLowerCase()]
  return adj ? `la casquette ${adj}` : `le coloris ${colorName}`
}

export function slugify(text: string) {
  return text
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export function dateFr(iso: string) {
  return new Intl.DateTimeFormat('fr-FR', { dateStyle: 'long', timeZone: 'Europe/Paris' }).format(new Date(iso))
}
