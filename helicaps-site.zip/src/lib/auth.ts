import 'server-only'
import { createHmac, timingSafeEqual } from 'node:crypto'
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { DEMO } from './store'

// Un seul compte peut entrer dans l'admin : celui dont l'e-mail est ADMIN_EMAIL.
// Chaque page et chaque action de /admin appelle requireAdmin() ; rien n'est protégé « par l'interface ».

const DEMO_COOKIE = 'helicaps_demo_admin'
const secure = process.env.NODE_ENV === 'production'
const adminEmail = () => (process.env.ADMIN_EMAIL ?? '').trim().toLowerCase()

const same = (a: string, b: string) => {
  const [x, y] = [a, b].map((s) => createHmac('sha256', 'helicaps').update(s).digest())
  return timingSafeEqual(x, y)
}

// Mode démo : cookie signé avec le mot de passe (impossible à fabriquer sans le connaître).
const demoToken = () => createHmac('sha256', process.env.ADMIN_PASSWORD!).update(`admin:${adminEmail()}`).digest('hex')

async function supabase() {
  const jar = await cookies()
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!, {
    cookies: {
      getAll: () => jar.getAll(),
      setAll: (list) => {
        try {
          // httpOnly : un script dans la page ne peut pas lire le cookie de session.
          for (const { name, value, options } of list) jar.set(name, value, { ...options, httpOnly: true, secure, sameSite: 'lax' })
        } catch {
          // Appelé depuis une page (lecture seule) : src/proxy.ts s'occupe de rafraîchir la session.
        }
      },
    },
  })
}

/** E-mail de l'admin connecté, ou null. */
export async function getAdmin(): Promise<string | null> {
  if (!adminEmail()) return null
  if (DEMO) {
    if (!process.env.ADMIN_PASSWORD) return null
    const token = (await cookies()).get(DEMO_COOKIE)?.value
    return token && same(token, demoToken()) ? adminEmail() : null
  }
  const { data } = await (await supabase()).auth.getUser()
  const user = data.user
  return user?.email_confirmed_at && user.email?.toLowerCase() === adminEmail() ? user.email : null
}

export async function requireAdmin() {
  if (!(await getAdmin())) redirect('/admin/connexion')
}

/** Renvoie true si la connexion a réussi. */
export async function signIn(email: string, password: string): Promise<boolean> {
  if (!adminEmail() || email.trim().toLowerCase() !== adminEmail()) return false
  if (DEMO) {
    if (!process.env.ADMIN_PASSWORD || !same(password, process.env.ADMIN_PASSWORD)) return false
    ;(await cookies()).set(DEMO_COOKIE, demoToken(), { httpOnly: true, sameSite: 'lax', secure, path: '/', maxAge: 60 * 60 * 24 * 7 })
    return true
  }
  const { error } = await (await supabase()).auth.signInWithPassword({ email, password })
  return !error
}

export async function signOut() {
  if (DEMO) (await cookies()).delete(DEMO_COOKIE)
  else await (await supabase()).auth.signOut()
}
