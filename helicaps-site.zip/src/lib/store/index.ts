import 'server-only'
import { randomUUID } from 'node:crypto'
import { parseEuros, slugify } from '../format'
import type { Product, ProductInput } from '../types'
import * as demo from './demo'
import * as supabase from './supabase'

/** Sans Supabase configuré, le site tourne sur un fichier local (.data/demo.json). */
export const DEMO = !process.env.NEXT_PUBLIC_SUPABASE_URL

// Les deux implémentations doivent exposer exactement les mêmes fonctions.
const impl: typeof supabase = DEMO ? demo : supabase

export const {
  listProducts,
  deleteProduct,
  setActive,
  adjustStock,
  uploadImage,
  reserve,
  release,
  completeOrder,
  listOrders,
  shipOrder,
  rateLimit,
} = impl

export type FieldErrors = Record<string, string>

const str = (value: unknown, max: number) => (typeof value === 'string' ? value.slice(0, max) : '')

/** Une photo ne peut venir que de ce site ou de notre espace de stockage Supabase. */
function isOurImage(url: string) {
  const storage = process.env.NEXT_PUBLIC_SUPABASE_URL ? `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/produits/` : null
  return (/^\/(images|uploads)\/[\w./-]+$/.test(url) && !url.includes('..')) || (!!storage && url.startsWith(storage) && !url.slice(storage.length).includes('/'))
}

/**
 * Remet au propre ce qu'envoie le formulaire admin : seuls les champs attendus sont gardés,
 * chacun au bon type et à une longueur raisonnable. null si la forme générale est fausse.
 */
export function cleanProductInput(raw: unknown): ProductInput | null {
  const input = raw as Record<string, unknown> | null
  if (!input || typeof input !== 'object' || !Array.isArray(input.variants) || input.variants.length > 50) return null
  return {
    id: typeof input.id === 'string' ? input.id.slice(0, 64) : undefined,
    name: str(input.name, 200),
    price: str(input.price, 20),
    description: str(input.description, 5000),
    variants: input.variants.map((v: Record<string, unknown> | null) => ({
      id: typeof v?.id === 'string' ? v.id.slice(0, 64) : undefined,
      color_name: str(v?.color_name, 100),
      swatch_hex: str(v?.swatch_hex, 7),
      stock: str(v?.stock, 5),
      images: (Array.isArray(v?.images) ? v.images.slice(0, 20) : [])
        .map((img: Record<string, unknown> | null) => ({ url: str(img?.url, 500), kind: img?.kind === 'worn' ? ('worn' as const) : ('studio' as const) }))
        .filter((img) => isOurImage(img.url)),
    })),
  }
}

/** Valide le formulaire admin. Les clés d'erreur sont les `name` des champs. */
export function validateProduct(input: ProductInput): FieldErrors {
  const errors: FieldErrors = {}
  if (!input.name.trim()) errors.name = 'Donnez un nom à la casquette.'
  else if (input.name.length > 80) errors.name = 'Le nom est trop long (80 caractères maximum).'
  const price = parseEuros(input.price)
  if (price === null || price < 100) errors.price = 'Indiquez un prix en euros, par exemple 90.'
  if (input.description.length > 2000) errors.description = 'La description est trop longue.'
  if (input.variants.length === 0) errors.variants = 'Ajoutez au moins un coloris.'
  if (input.variants.length > 12) errors.variants = 'Douze coloris maximum.'
  input.variants.forEach((v, i) => {
    if (!v.color_name.trim()) errors[`variants.${i}.color_name`] = 'Donnez un nom au coloris.'
    else if (v.color_name.length > 30) errors[`variants.${i}.color_name`] = 'Le nom du coloris est trop long.'
    else if (input.variants.findIndex((o) => slugify(o.color_name) === slugify(v.color_name)) !== i)
      errors[`variants.${i}.color_name`] = 'Ce coloris existe déjà sur cette casquette.'
    if (!/^#[0-9a-f]{6}$/i.test(v.swatch_hex)) errors[`variants.${i}.swatch_hex`] = 'Choisissez la couleur de la pastille.'
    if (!v.id && !/^\d{1,3}$/.test(v.stock.trim())) errors[`variants.${i}.stock`] = 'Indiquez le nombre de pièces, par exemple 3.'
    if (v.images.length === 0) errors[`variants.${i}.images`] = 'Ajoutez au moins une photo de ce coloris.'
    if (v.images.length > 10) errors[`variants.${i}.images`] = 'Dix photos maximum par coloris.'
  })
  return errors
}

/** Crée ou met à jour une casquette. `input` doit avoir passé validateProduct. */
export async function saveProduct(input: ProductInput): Promise<string> {
  const all = await listProducts(true)
  const existing = all.find((p) => p.id === input.id)
  const others = all.filter((p) => p.id !== existing?.id)
  const takenSlugs = new Set(others.map((p) => p.slug))
  const takenColors = new Set(others.flatMap((p) => p.variants.map((v) => v.color_slug)))

  const name = input.name.trim()
  let slug = slugify(name) || 'casquette'
  for (let n = 2; takenSlugs.has(slug); n++) slug = `${slugify(name)}-${n}`

  const id = existing?.id ?? randomUUID()
  const product: Product = {
    id,
    name,
    slug,
    description: input.description.trim(),
    price_cents: parseEuros(input.price)!,
    is_active: existing?.is_active ?? true,
    created_at: existing?.created_at ?? new Date().toISOString(),
    variants: input.variants.map((v, i) => {
      const before = existing?.variants.find((e) => e.id === v.id)
      const color = slugify(v.color_name) || `coloris-${i + 1}`
      const variantId = before?.id ?? randomUUID()
      // Le stock d'un coloris existant ne se change que par −/+ (opération atomique) :
      // réécrire ici une valeur lue il y a deux minutes pourrait revendre une pièce déjà partie.
      const stock = before?.stock ?? Number(v.stock)
      return {
        id: variantId,
        product_id: id,
        color_name: v.color_name.trim(),
        // /casquette/bleu pour le premier modèle, /casquette/<modèle>-bleu si « bleu » est déjà pris.
        color_slug: takenColors.has(color) ? `${slug}-${color}` : color,
        swatch_hex: v.swatch_hex.toLowerCase(),
        stock,
        stock_initial: before?.stock_initial ?? stock,
        sort_order: i,
        images: v.images.map((img, j) => ({
          id: randomUUID(),
          url: img.url,
          alt: `${name}, ${v.color_name.trim().toLowerCase()}${img.kind === 'worn' ? ', portée' : ''}`,
          kind: img.kind,
          sort_order: j,
        })),
      }
    }),
  }
  await impl.writeProduct(product, !existing)
  return id
}
