// Production : Postgres + Storage Supabase, toujours depuis le serveur avec la clé secrète (sb_secret_…).
// Le schéma, les règles RLS et les fonctions appelées ici sont dans supabase/schema.sql.
import { randomUUID } from 'node:crypto'
import { createClient } from '@supabase/supabase-js'
import type { NewOrder, Order, Product, ReservationItem } from '../types'

const BUCKET = 'produits'

function db() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SECRET_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
}

function ok<T>({ data, error }: { data: T; error: { message: string } | null }): T {
  if (error) throw new Error(`Supabase : ${error.message}`)
  return data
}

const bySort = (a: { sort_order: number }, b: { sort_order: number }) => a.sort_order - b.sort_order

export async function listProducts(all = false): Promise<Product[]> {
  let query = db().from('products').select('*, variants(*, images:product_images(*))').order('created_at')
  if (!all) query = query.eq('is_active', true)
  const products = ok(await query) as Product[]
  for (const p of products) {
    p.variants.sort(bySort)
    for (const v of p.variants) v.images.sort(bySort)
  }
  return products
}

// ponytail: plusieurs requêtes sans transaction ; si l'une échoue, l'admin ré-enregistre le formulaire.
// À passer en une fonction SQL si plusieurs personnes modifient le catalogue en même temps.
export async function writeProduct(product: Product, isNew: boolean) {
  const client = db()
  const { variants, ...row } = product
  ok(await client.from('products').upsert(row))

  const ids = variants.map((v) => v.id)
  if (!isNew) ok(await client.from('variants').delete().eq('product_id', product.id).not('id', 'in', `(${ids.join(',')})`))
  for (const { images, stock, stock_initial, ...v } of variants) {
    const exists = ok(await client.from('variants').select('id').eq('id', v.id).maybeSingle())
    // Le stock n'est écrit qu'à la création d'un coloris (ensuite : adjust_stock uniquement).
    ok(exists ? await client.from('variants').update(v).eq('id', v.id) : await client.from('variants').insert({ ...v, stock, stock_initial }))
    ok(await client.from('product_images').delete().eq('variant_id', v.id))
    if (images.length) ok(await client.from('product_images').insert(images.map((img) => ({ ...img, variant_id: v.id }))))
  }
}

export async function deleteProduct(id: string) {
  ok(await db().from('products').delete().eq('id', id))
}

export async function setActive(id: string, active: boolean) {
  ok(await db().from('products').update({ is_active: active }).eq('id', id))
}

export async function adjustStock(variantId: string, delta: number) {
  ok(await db().rpc('adjust_stock', { p_variant: variantId, p_delta: delta }))
}

export async function uploadImage(file: File): Promise<string> {
  const name = `${randomUUID()}.${file.type === 'image/png' ? 'png' : 'jpg'}`
  const storage = db().storage.from(BUCKET)
  ok(await storage.upload(name, file, { contentType: file.type, cacheControl: '31536000' }))
  return storage.getPublicUrl(name).data.publicUrl
}

/** Réserve le stock d'un panier, tout ou rien. false = au moins une pièce n'est plus disponible. */
export async function reserve(reservationId: string, items: ReservationItem[], expiresAt: Date): Promise<boolean> {
  return ok(
    await db().rpc('reserve_stock', { p_reservation: reservationId, p_items: items, p_expires: expiresAt.toISOString() }),
  ) as boolean
}

export async function release(reservationId: string) {
  ok(await db().rpc('release_reservation', { p_reservation: reservationId }))
}

export async function completeOrder(reservationId: string, order: NewOrder): Promise<Order> {
  const client = db()
  const id = ok(await client.rpc('complete_order', { p_reservation: reservationId, p_order: order })) as string
  return ok(await client.from('orders').select('*, items:order_items(*)').eq('id', id).single()) as Order
}

/** Compte un essai pour `key`. true tant qu'on reste sous `max` essais par fenêtre de `seconds` secondes. */
export async function rateLimit(key: string, max: number, seconds: number): Promise<boolean> {
  return ok(await db().rpc('rate_limit', { p_key: key, p_max: max, p_window: seconds })) as boolean
}

export async function listOrders(): Promise<Order[]> {
  return ok(await db().from('orders').select('*, items:order_items(*)').order('created_at')) as Order[]
}

/** Passe une commande payée à « expédiée ». null si elle n'existe pas ou l'est déjà. */
export async function shipOrder(id: string, tracking: string | null): Promise<Order | null> {
  return ok(
    await db()
      .from('orders')
      .update({ status: 'shipped', tracking_number: tracking, shipped_at: new Date().toISOString() })
      .eq('id', id)
      .eq('status', 'paid')
      .select('*, items:order_items(*)')
      .maybeSingle(),
  ) as Order | null
}
