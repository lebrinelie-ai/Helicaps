// Mode démo : toute la « base » tient dans .data/demo.json. Sert à voir le site tourner
// sans aucun compte. En production, c'est store/supabase.ts qui est utilisé.
import { randomUUID } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import type { NewOrder, Order, Product, ReservationItem } from '../types'

type Reservation = ReservationItem & { reservation_id: string }
type Db = { products: Product[]; orders: Order[]; reservations: Reservation[] }

const FILE = path.join(process.cwd(), '.data', 'demo.json')

const COLORIS = [
  { slug: 'noir', name: 'Noir', hex: '#1f1f1f', adj: 'noire' },
  { slug: 'bleu', name: 'Bleu', hex: '#24427c', adj: 'bleue' },
  { slug: 'vert', name: 'Vert', hex: '#2f5d42', adj: 'verte' },
]

function seed(): Db {
  const id = randomUUID()
  return {
    orders: [],
    reservations: [],
    products: [
      {
        id,
        name: 'Casquette Helicaps',
        slug: 'casquette-helicaps',
        description: '[Description de la casquette : matière, coupe, finitions.]',
        price_cents: 9000,
        is_active: true,
        created_at: new Date().toISOString(),
        variants: COLORIS.map((c, i) => {
          const variantId = randomUUID()
          return {
            id: variantId,
            product_id: id,
            color_name: c.name,
            color_slug: c.slug,
            swatch_hex: c.hex,
            stock: 3,
            stock_initial: 3,
            sort_order: i,
            images: [
              {
                id: randomUUID(),
                url: `/images/placeholders/cap-${c.slug}.svg`,
                alt: `Casquette Helicaps ${c.adj}, visuel provisoire`,
                kind: 'studio' as const,
                sort_order: 0,
              },
            ],
          }
        }),
      },
    ],
  }
}

function load(): Db {
  // Le mode démo simule les paiements : il ne doit jamais tourner sur un site en ligne.
  // ALLOW_DEMO=1 sert uniquement à tester une version de production sur son propre ordinateur.
  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_DEMO !== '1') {
    throw new Error('Site non configuré : les variables Supabase sont absentes (le mode démo est interdit en production).')
  }
  if (!existsSync(FILE)) save(seed())
  return JSON.parse(readFileSync(FILE, 'utf8'))
}

function save(db: Db) {
  mkdirSync(path.dirname(FILE), { recursive: true })
  writeFileSync(FILE, JSON.stringify(db, null, 2))
}

const variantsOf = (db: Db) => db.products.flatMap((p) => p.variants)

export async function listProducts(all = false): Promise<Product[]> {
  const { products } = load()
  return all ? products : products.filter((p) => p.is_active)
}

export async function writeProduct(product: Product, _isNew: boolean) {
  const db = load()
  const i = db.products.findIndex((p) => p.id === product.id)
  if (i === -1) db.products.push(product)
  else db.products[i] = product
  save(db)
}

export async function deleteProduct(id: string) {
  const db = load()
  db.products = db.products.filter((p) => p.id !== id)
  save(db)
}

export async function setActive(id: string, active: boolean) {
  const db = load()
  const product = db.products.find((p) => p.id === id)
  if (product) product.is_active = active
  save(db)
}

export async function adjustStock(variantId: string, delta: number) {
  const db = load()
  const variant = variantsOf(db).find((v) => v.id === variantId)
  if (!variant) return
  variant.stock = Math.max(0, variant.stock + delta)
  variant.stock_initial = Math.max(variant.stock_initial, variant.stock)
  save(db)
}

export async function uploadImage(file: File): Promise<string> {
  const name = `${randomUUID()}.${file.type === 'image/png' ? 'png' : 'jpg'}`
  const dir = path.join(process.cwd(), 'public', 'uploads')
  mkdirSync(dir, { recursive: true })
  writeFileSync(path.join(dir, name), Buffer.from(await file.arrayBuffer()))
  return `/uploads/${name}`
}

/** Réserve le stock d'un panier, tout ou rien. false = au moins une pièce n'est plus disponible. */
export async function reserve(reservationId: string, items: ReservationItem[], _expiresAt: Date): Promise<boolean> {
  const db = load()
  const variants = variantsOf(db)
  if (!items.every((it) => (variants.find((v) => v.id === it.variant_id)?.stock ?? 0) >= it.quantity)) return false
  for (const it of items) {
    variants.find((v) => v.id === it.variant_id)!.stock -= it.quantity
    db.reservations.push({ ...it, reservation_id: reservationId })
  }
  save(db)
  return true
}

export async function release(reservationId: string) {
  const db = load()
  for (const r of db.reservations.filter((r) => r.reservation_id === reservationId)) {
    const variant = variantsOf(db).find((v) => v.id === r.variant_id)
    if (variant) variant.stock += r.quantity
  }
  db.reservations = db.reservations.filter((r) => r.reservation_id !== reservationId)
  save(db)
}

export async function completeOrder(reservationId: string, order: NewOrder): Promise<Order> {
  const db = load()
  const done = db.orders.find((o) => o.stripe_session_id === order.stripe_session_id)
  if (done) return done
  const created: Order = {
    ...order,
    id: randomUUID(),
    number: `HC-${1001 + db.orders.length}`,
    status: 'paid',
    tracking_number: null,
    shipped_at: null,
    created_at: new Date().toISOString(),
    items: db.reservations
      .filter((r) => r.reservation_id === reservationId)
      .map((r) => {
        const product = db.products.find((p) => p.variants.some((v) => v.id === r.variant_id))
        return {
          variant_id: r.variant_id,
          product_name: product?.name ?? '',
          color_name: product?.variants.find((v) => v.id === r.variant_id)?.color_name ?? '',
          quantity: r.quantity,
          unit_price_cents: r.unit_price_cents,
        }
      }),
  }
  db.orders.push(created)
  db.reservations = db.reservations.filter((r) => r.reservation_id !== reservationId)
  save(db)
  return created
}

const hits = new Map<string, { bucket: number; count: number }>()

/** Compte un essai pour `key`. true tant qu'on reste sous `max` essais par fenêtre de `seconds` secondes. */
export async function rateLimit(key: string, max: number, seconds: number): Promise<boolean> {
  const bucket = Math.floor(Date.now() / 1000 / seconds)
  const previous = hits.get(key)
  const count = previous?.bucket === bucket ? previous.count + 1 : 1
  hits.set(key, { bucket, count })
  return count <= max
}

export async function listOrders(): Promise<Order[]> {
  return load().orders
}

/** Passe une commande payée à « expédiée ». null si elle n'existe pas ou l'est déjà. */
export async function shipOrder(id: string, tracking: string | null): Promise<Order | null> {
  const db = load()
  const order = db.orders.find((o) => o.id === id && o.status === 'paid')
  if (!order) return null
  Object.assign(order, { status: 'shipped', tracking_number: tracking, shipped_at: new Date().toISOString() })
  save(db)
  return order
}
