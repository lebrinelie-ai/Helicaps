import 'server-only'
import { createHash } from 'node:crypto'
import { rateLimit } from './store'

/**
 * Journal de sécurité : une ligne JSON par événement, lisible dans les journaux de l'hébergeur
 * (Netlify > Logs > Functions). Ne jamais y mettre de mot de passe, de clé ni d'adresse IP en clair.
 */
export function audit(event: string, data: Record<string, unknown> = {}) {
  console.log(JSON.stringify({ t: new Date().toISOString(), event, ...data }))
}

/** Empreinte anonyme de l'adresse IP du visiteur : sert à compter ses essais, pas à l'identifier. */
export function visitor(headers: Headers) {
  // x-nf-client-connection-ip est posé par Netlify : le visiteur ne peut pas le falsifier.
  // ponytail: ailleurs que chez Netlify, x-forwarded-for peut être forgé pour contourner les limites ;
  // lire alors l'en-tête de confiance de l'hébergeur choisi.
  const ip = headers.get('x-nf-client-connection-ip') ?? headers.get('x-forwarded-for')?.split(',')[0].trim() ?? 'inconnu'
  return createHash('sha256').update(ip).digest('hex').slice(0, 16)
}

/**
 * true si ce visiteur peut encore faire cette action (au plus `max` fois par fenêtre de `seconds` secondes).
 * Si le compteur lui-même est en panne, on laisse passer et on le note : la boutique reste ouverte.
 */
export async function allow(action: string, headers: Headers, max: number, seconds: number) {
  const who = visitor(headers)
  try {
    const ok = await rateLimit(`${action}:${who}`, max, seconds)
    if (!ok) audit('limite_atteinte', { action, visiteur: who })
    return ok
  } catch (error) {
    audit('limite_indisponible', { action, erreur: String(error).slice(0, 200) })
    return true
  }
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
export const isUuid = (value: unknown): value is string => typeof value === 'string' && UUID.test(value)

/** Lit un corps JSON en refusant tout ce qui dépasse `maxBytes`. null si absent, trop gros ou illisible. */
export async function readJson(request: Request, maxBytes = 10_000): Promise<Record<string, unknown> | null> {
  if (Number(request.headers.get('content-length') ?? 0) > maxBytes) return null
  const text = await request.text().catch(() => '')
  if (!text || text.length > maxBytes) return null
  try {
    const value = JSON.parse(text)
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null
  } catch {
    return null
  }
}

/** Vérifie que le fichier est bien un JPEG ou un PNG en lisant ses premiers octets (le type annoncé ne prouve rien). */
export async function isRealImage(file: File) {
  const head = new Uint8Array(await file.slice(0, 8).arrayBuffer())
  const png = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
  if (file.type === 'image/png') return png.every((byte, i) => head[i] === byte)
  if (file.type === 'image/jpeg') return head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff
  return false
}
