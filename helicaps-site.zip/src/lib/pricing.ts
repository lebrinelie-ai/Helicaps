export const SHIPPING_CENTS = 300
export const FREE_SHIPPING_FROM_CENTS = 18000

export type Discount = { percent_off: number | null; amount_off: number | null }

/** Seul endroit où se calculent réduction, frais de port et total. Toujours appelé côté serveur. */
export function totals(subtotal_cents: number, discount?: Discount | null) {
  // ponytail: réduction calculée sur le sous-total ; Stripe la répartit par ligne et peut différer
  // d'un centime sur un pourcentage non rond. Le montant débité est celui de Stripe.
  const raw = discount ? (discount.amount_off ?? Math.round((subtotal_cents * (discount.percent_off ?? 0)) / 100)) : 0
  const discount_cents = Math.min(subtotal_cents, Math.max(0, raw))
  const after = subtotal_cents - discount_cents
  const shipping_cents = after >= FREE_SHIPPING_FROM_CENTS ? 0 : SHIPPING_CENTS
  return {
    subtotal_cents,
    discount_cents,
    shipping_cents,
    total_cents: after + shipping_cents,
    free_shipping_missing_cents: Math.max(0, FREE_SHIPPING_FROM_CENTS - after),
  }
}
