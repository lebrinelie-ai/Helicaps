import 'server-only'
import Stripe from 'stripe'
import { totals, type Discount } from './pricing'
import { listProducts } from './store'
import type { CartItem, CartLine, Quote, Relay } from './types'

export const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null

const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim().length > 0 && v.length <= max ? v.trim() : null)

/** Nettoie ce que le navigateur envoie : jamais plus de 20 lignes, quantités entières positives. */
export function parseItems(input: unknown): CartItem[] | null {
  if (!Array.isArray(input) || input.length > 20) return null
  const merged = new Map<string, number>()
  for (const it of input) {
    const id = text(it?.variantId, 64)
    if (!id || !Number.isInteger(it.quantity) || it.quantity < 1 || it.quantity > 99) return null
    merged.set(id, (merged.get(id) ?? 0) + it.quantity)
  }
  return [...merged].map(([variantId, quantity]) => ({ variantId, quantity }))
}

export function parsePromo(input: unknown): string | null {
  return text(input, 40)
}

export function parseRelay(input: unknown): Relay | null {
  const r = input as Record<string, unknown> | null
  const relay = {
    id: text(r?.id, 12),
    name: text(r?.name, 80),
    address: text(r?.address, 160),
    zip: text(r?.zip, 10),
    city: text(r?.city, 80),
  }
  return Object.values(relay).every(Boolean) ? (relay as Relay) : null
}

type Promo = Discount & { id: string }

/** Les codes promo vivent dans Stripe (Promotion Codes). null = inconnu, expiré ou désactivé. */
async function findPromo(code: string): Promise<Promo | null> {
  if (!stripe) return null
  const { data } = await stripe.promotionCodes.list({ code, active: true, limit: 1, expand: ['data.promotion.coupon'] })
  const coupon = data[0]?.promotion.coupon
  if (!coupon || typeof coupon === 'string' || !coupon.valid) return null
  if (coupon.amount_off && coupon.currency !== 'eur') return null
  return { id: data[0].id, percent_off: coupon.percent_off, amount_off: coupon.amount_off }
}

/**
 * Recalcule le panier depuis la base : prix, stock, réduction, frais de port.
 * Les quantités sont ramenées au stock disponible ; les articles retirés de la vente disparaissent.
 */
export async function quoteCart(items: CartItem[], promoCode: string | null): Promise<Quote & { promoId: string | null }> {
  const products = await listProducts()
  const lines: CartLine[] = []
  for (const item of items) {
    const product = products.find((p) => p.variants.some((v) => v.id === item.variantId))
    const variant = product?.variants.find((v) => v.id === item.variantId)
    if (!product || !variant || variant.stock < 1) continue
    lines.push({
      variantId: variant.id,
      quantity: Math.min(item.quantity, variant.stock),
      product_name: product.name,
      color_name: variant.color_name,
      color_slug: variant.color_slug,
      image: variant.images[0]?.url ?? null,
      unit_price_cents: product.price_cents,
      stock: variant.stock,
    })
  }
  // Si Stripe ne répond pas, le code est simplement refusé : le panier reste utilisable.
  const promo = promoCode ? await findPromo(promoCode).catch(() => null) : null
  const subtotal = lines.reduce((sum, l) => sum + l.unit_price_cents * l.quantity, 0)
  return {
    lines,
    ...totals(subtotal, promo),
    promo: promoCode ? { code: promoCode, valid: !!promo } : null,
    promoId: promo?.id ?? null,
  }
}

/** true si le serveur a dû corriger le panier (stock parti entre-temps). */
export function changed(asked: CartItem[], lines: CartLine[]) {
  return asked.length !== lines.length || asked.some((a) => lines.find((l) => l.variantId === a.variantId)?.quantity !== a.quantity)
}
