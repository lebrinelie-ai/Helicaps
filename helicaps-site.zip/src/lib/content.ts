// Textes et emplacements à remplir par le propriétaire. Rien ici n'est secret.

export const SITE = {
  name: 'Helicaps',
  tagline: 'Le luxe à tous les coins de rue.',
  description: 'Casquettes streetwear haut de gamme, en série très limitée. Livraison en point relais Mondial Relay.',
  // URL : adresse principale du site, fournie automatiquement par Netlify.
  url: process.env.NEXT_PUBLIC_SITE_URL || process.env.URL || 'http://localhost:3000',
}

export const TAILLE = 'Taille unique M'

// Emplacements : remplacer le pseudo et mettre le vrai lien.
export const RESEAUX = [
  { id: 'instagram', name: 'Instagram', handle: '[@helicaps]', url: '#' },
  { id: 'tiktok', name: 'TikTok', handle: '[@helicaps]', url: '#' },
] as const

export type Avis = { note: 1 | 2 | 3 | 4 | 5; texte: string; auteur: string; coloris: string }

// Uniquement de vrais avis. Tant que la liste est vide, la section « Avis clients » n'apparaît pas.
export const AVIS: Avis[] = []

// Accordéons de la page produit.
export const INFOS_PRODUIT = [
  {
    titre: 'Livraison et retours',
    texte:
      'Livraison en point relais Mondial Relay, expédiée sous 2 jours. Vous disposez de 14 jours après réception pour changer d’avis. [Compléter : conditions de retour.]',
  },
  { titre: 'Entretien', texte: '[Conseils d’entretien à fournir : lavage, séchage, rangement.]' },
]

type Page = { titre: string; sections: { titre?: string; texte: string }[] }

// Pages d'information. Tout ce qui est entre crochets est à fournir par le propriétaire.
export const PAGES: Record<string, Page> = {
  'livraison-et-retours': {
    titre: 'Livraison et retours',
    sections: [
      {
        titre: 'Livraison',
        texte:
          'Les commandes sont livrées en point relais Mondial Relay. [Préciser les zones livrées.] La livraison coûte 3 € et elle est offerte dès 180 € d’achat. Chaque commande est expédiée sous 2 jours et vous recevez un e-mail avec le suivi du colis.',
      },
      {
        titre: 'Droit de rétractation',
        texte:
          'Vous disposez de 14 jours à compter de la réception de votre commande pour changer d’avis, sans avoir à vous justifier. [Compléter : adresse de retour, état attendu de l’article, qui paie les frais de retour, délai de remboursement.]',
      },
      { titre: 'Échanges', texte: '[Compléter : conditions d’échange, ou indiquer qu’il n’y en a pas.]' },
    ],
  },
  contact: {
    titre: 'Contact',
    sections: [
      { texte: 'Une question sur une commande ou sur la casquette ? Écrivez-nous, nous répondons sous [délai].' },
      { titre: 'E-mail', texte: '[adresse e-mail de contact]' },
    ],
  },
  cgv: {
    titre: 'Conditions générales de vente',
    sections: [
      {
        texte:
          '[Texte des CGV à fournir par le propriétaire : identité du vendeur, prix, commande, paiement, livraison, droit de rétractation, garanties légales, médiateur de la consommation, droit applicable.]',
      },
    ],
  },
  'mentions-legales': {
    titre: 'Mentions légales',
    sections: [
      { titre: 'Éditeur du site', texte: '[Nom ou raison sociale, statut, adresse, numéro SIREN, e-mail, téléphone.]' },
      { titre: 'Directeur de la publication', texte: '[Nom et prénom.]' },
      { titre: 'Hébergeur', texte: '[Nom, adresse et téléphone de l’hébergeur du site.]' },
    ],
  },
  confidentialite: {
    titre: 'Politique de confidentialité',
    sections: [
      {
        titre: 'Données collectées',
        texte:
          'Pour traiter une commande, nous recevons votre nom, votre e-mail, votre téléphone et le point relais choisi. Le paiement est réalisé par Stripe : nous ne voyons jamais votre numéro de carte.',
      },
      {
        titre: 'Vos droits',
        texte:
          '[Compléter : responsable du traitement, durée de conservation, comment exercer vos droits d’accès, de rectification et de suppression, contact.]',
      },
      {
        titre: 'Cookies',
        texte: 'Le site n’utilise aucun cookie publicitaire ni de mesure d’audience. Votre panier est conservé dans votre navigateur.',
      },
    ],
  },
}

export const LIENS_PIED = [
  { href: '/livraison-et-retours', label: 'Livraison et retours' },
  { href: '/contact', label: 'Contact' },
  { href: '/cgv', label: 'CGV' },
  { href: '/mentions-legales', label: 'Mentions légales' },
  { href: '/confidentialite', label: 'Confidentialité' },
]
