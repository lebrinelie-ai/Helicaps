// Rejoue supabase/schema.sql sur un Postgres embarqué (PGlite) et vérifie le stock, les commandes et la RLS.

import { PGlite } from '@electric-sql/pglite'
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto'
import { readFileSync } from 'node:fs'
import assert from 'node:assert/strict'

const db = new PGlite({ extensions: { pgcrypto } })
// Ce que Supabase fournit d'office : les rôles et le schéma storage.
await db.exec(`create role anon; create role authenticated; create role service_role bypassrls; create schema storage;
  create table storage.buckets (id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);`)
await db.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'))

const one = async (sql, p = []) => (await db.query(sql, p)).rows[0]
const stock = async (slug) => (await one('select stock from variants where color_slug = $1', [slug])).stock
const vid = async (slug) => (await one('select id from variants where color_slug = $1', [slug])).id
const bleu = await vid('bleu'), noir = await vid('noir')
const items = (list) => JSON.stringify(list.map(([variant_id, quantity]) => ({ variant_id, quantity, unit_price_cents: 9000 })))
const soon = new Date(Date.now() + 35 * 60000).toISOString()
const order = (sid) => JSON.stringify({ stripe_session_id: sid, email: 'a@b.fr', customer_name: 'A', phone: '', relay_id: '1', relay_name: 'R', relay_address: 'x', relay_zip: '75011', relay_city: 'Paris', subtotal_cents: 18000, shipping_cents: 0, discount_cents: 0, total_cents: 18000 })

// 1. Données de départ
assert.equal((await one('select count(*)::int n, sum(stock)::int s from variants')).s, 9)
assert.equal((await one('select count(*)::int n from product_images')).n, 3)

// 2. Réservation : 2 bleues → stock 1
const r1 = '11111111-1111-1111-1111-111111111111'
assert.equal((await one('select reserve_stock($1,$2,$3) ok', [r1, items([[bleu, 2]]), soon])).ok, true)
assert.equal(await stock('bleu'), 1)

// 3. Un autre panier veut 1 noire + 2 bleues : refusé EN ENTIER (la noire n'est pas prise)
const r2 = '22222222-2222-2222-2222-222222222222'
assert.equal((await one('select reserve_stock($1,$2,$3) ok', [r2, items([[noir, 1], [bleu, 2]]), soon])).ok, false)
assert.equal(await stock('noir'), 3)
assert.equal(await stock('bleu'), 1)
assert.equal((await one('select count(*)::int n from stock_reservations where reservation_id = $1', [r2])).n, 0)

// 4. Paiement confirmé : commande créée, stock définitif, rejouable sans doublon
const o1 = (await one('select complete_order($1,$2) id', [r1, order('cs_1')])).id
const o1bis = (await one('select complete_order($1,$2) id', [r1, order('cs_1')])).id
assert.equal(o1, o1bis)
assert.equal((await one('select count(*)::int n from orders')).n, 1)
const item = await one('select * from order_items where order_id = $1', [o1])
assert.deepEqual([item.product_name, item.color_name, item.quantity, item.unit_price_cents], ['Casquette Helicaps', 'Bleu', 2, 9000])
assert.equal((await one('select number from orders')).number, 'HC-1001')
assert.equal(await stock('bleu'), 1)

// 5. Session expirée : le stock revient, une seule fois
const r3 = '33333333-3333-3333-3333-333333333333'
await one('select reserve_stock($1,$2,$3)', [r3, items([[noir, 3]]), soon])
assert.equal(await stock('noir'), 0)
await db.query('select release_reservation($1)', [r3])
await db.query('select release_reservation($1)', [r3])
assert.equal(await stock('noir'), 3)

// 6. Payé APRÈS expiration (webhook en retard) : la commande existe quand même et le stock est repris
const o3 = (await one('select complete_order($1,$2) id', [r3, order('cs_3')])).id
assert.equal((await one('select quantity from order_items where order_id = $1', [o3])).quantity, 3)
assert.equal(await stock('noir'), 0)

// 7. Réservation oubliée (webhook jamais arrivé) : libérée à la réservation suivante
const r4 = '44444444-4444-4444-4444-444444444444'
await one('select reserve_stock($1,$2,$3)', [r4, items([[bleu, 1]]), new Date(Date.now() - 60000).toISOString()])
assert.equal(await stock('bleu'), 0)
const r5 = '55555555-5555-5555-5555-555555555555'
assert.equal((await one('select reserve_stock($1,$2,$3) ok', [r5, items([[bleu, 1]]), soon])).ok, true)
assert.equal(await stock('bleu'), 0)

// 8. −/+ de l'admin : jamais sous zéro, « sur N » suit si on dépasse
await db.query('select adjust_stock($1, -1)', [bleu])
assert.equal(await stock('bleu'), 0)
await db.query('select adjust_stock($1, 1)', [noir]); await db.query('select adjust_stock($1, 1)', [noir])
const vert = await vid('vert')
for (let i = 0; i < 2; i++) await db.query('select adjust_stock($1, 1)', [vert])
assert.deepEqual(await one('select stock, stock_initial from variants where id = $1', [vert]), { stock: 5, stock_initial: 5 })

// 9. Supprimer la casquette ne casse pas les commandes
await db.query('delete from products')
assert.equal((await one('select count(*)::int n from order_items where variant_id is null')).n, 2)

// 10. Le serveur (service_role) peut tout faire, y compris appeler les fonctions de stock
await db.exec(`insert into products (name, slug, price_cents, is_active) values ('Cachée', 'cachee', 100, false), ('Visible', 'visible', 100, true);
  set role service_role;`)
assert.equal((await one('select count(*)::int n from orders')).n, 2)
await db.query(`select adjust_stock('${vert}', 1)`)
await db.exec('reset role')

// 11. RLS : avec la clé publique, lecture du catalogue en ligne seulement, aucune commande, aucune écriture
await db.exec('set role anon')
assert.deepEqual((await db.query('select name from products')).rows, [{ name: 'Visible' }])
await assert.rejects(db.query('select count(*) from orders'), /permission denied/)
await assert.rejects(db.query(`insert into products (name, slug, price_cents) values ('Pirate', 'pirate', 1)`), /permission denied|row-level security/)
await assert.rejects(db.query('update products set price_cents = 1'), /permission denied/)
await assert.rejects(db.query(`select adjust_stock('${vert}', 5)`), /permission denied/)
await assert.rejects(db.query(`select rate_limit('x', 1, 60)`), /permission denied/)
await assert.rejects(db.query('select * from rate_limits'), /permission denied/)
await db.exec('reset role')

// 12. Limite anti-abus : 3 essais passent, le 4e est refusé, une autre clé n'est pas touchée
const tries = []
for (let i = 0; i < 4; i++) tries.push((await one(`select rate_limit('connexion:abc', 3, 600) ok`)).ok)
assert.deepEqual(tries, [true, true, true, false])
assert.equal((await one(`select rate_limit('connexion:autre', 3, 600) ok`)).ok, true)
// une fenêtre expirée est oubliée
await db.exec(`update rate_limits set expires_at = now() - interval '1 second', bucket = bucket - 1 where key = 'connexion:abc'`)
assert.equal((await one(`select rate_limit('connexion:abc', 3, 600) ok`)).ok, true)
assert.equal((await one(`select count(*)::int n from rate_limits where key = 'connexion:abc'`)).n, 1)
assert.deepEqual(await one(`select file_size_limit::int s, allowed_mime_types t from storage.buckets where id = 'produits'`), { s: 4194304, t: ['image/jpeg', 'image/png'] })
console.log('SQL : les 12 scénarios passent')
