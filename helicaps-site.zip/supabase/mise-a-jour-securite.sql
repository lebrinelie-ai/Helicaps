-- À lancer UNIQUEMENT si la base a été créée avec une version de schema.sql d'avant le 13/10/2026
-- (sans la table rate_limits). Sans danger si on le relance. Une base créée avec le schema.sql actuel n'en a pas besoin.

create table if not exists rate_limits (
  key text not null,
  bucket bigint not null,
  hits integer not null default 1,
  expires_at timestamptz not null,
  primary key (key, bucket)
);
alter table rate_limits enable row level security;

create or replace function rate_limit(p_key text, p_max integer, p_window integer) returns boolean
language plpgsql as $$
declare
  v_bucket bigint := floor(extract(epoch from now()) / p_window);
  v_hits integer;
begin
  delete from rate_limits where expires_at < now();
  insert into rate_limits (key, bucket, expires_at)
  values (p_key, v_bucket, now() + make_interval(secs => p_window))
  on conflict (key, bucket) do update set hits = rate_limits.hits + 1
  returning hits into v_hits;
  return v_hits <= p_max;
end;
$$;

revoke execute on function rate_limit(text, integer, integer) from public, anon, authenticated;
grant all on rate_limits to service_role;
grant execute on function rate_limit(text, integer, integer) to service_role;

update storage.buckets
set file_size_limit = 4194304, allowed_mime_types = array['image/jpeg', 'image/png']
where id = 'produits';
