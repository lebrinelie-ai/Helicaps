-- Helicaps : schéma complet. À coller une fois dans Supabase > SQL Editor > Run.
-- Tout le site lit et écrit via le serveur (clé secrète). Les clés publiques (publishable)
-- ne peuvent que lire le catalogue en ligne : aucune règle d'écriture n'existe pour elles.

create extension if not exists pgcrypto;

-- ---------- Catalogue ----------
create table products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  price_cents integer not null check (price_cents > 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products on delete cascade,
  color_name text not null,
  color_slug text not null unique,           -- /casquette/<color_slug>
  swatch_hex text not null,
  stock integer not null default 0 check (stock >= 0),          -- pièces en vente (réservations déjà déduites)
  stock_initial integer not null default 0 check (stock_initial >= 0), -- pièces fabriquées (« sur 9 »)
  sort_order integer not null default 0
);

create table product_images (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references variants on delete cascade,
  url text not null,
  alt text not null default '',
  kind text not null default 'studio' check (kind in ('studio', 'worn')),
  sort_order integer not null default 0
);

-- ---------- Commandes ----------
create sequence order_number_seq start 1001;

create table orders (
  id uuid primary key default gen_random_uuid(),
  number text not null unique default 'HC-' || nextval('order_number_seq'),
  stripe_session_id text not null unique,
  email text not null default '',
  customer_name text not null default '',
  phone text not null default '',
  relay_id text not null default '',
  relay_name text not null default '',
  relay_address text not null default '',
  relay_zip text not null default '',
  relay_city text not null default '',
  subtotal_cents integer not null,
  shipping_cents integer not null,
  discount_cents integer not null default 0,
  total_cents integer not null,
  status text not null default 'paid' check (status in ('paid', 'shipped', 'cancelled')),
  tracking_number text,
  shipped_at timestamptz,
  created_at timestamptz not null default now()
);

-- Le nom et le coloris sont recopiés : la commande reste lisible si la casquette est supprimée.
create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders on delete cascade,
  variant_id uuid references variants on delete set null,
  product_name text not null,
  color_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price_cents integer not null
);

-- Une ligne par coloris d'un panier en cours de paiement. Le stock est déduit dès la réservation
-- et rendu si la session Stripe expire : deux clients ne peuvent jamais payer la même pièce.
create table stock_reservations (
  id uuid primary key default gen_random_uuid(),
  reservation_id uuid not null,              -- passé à Stripe dans les métadonnées de la session
  variant_id uuid references variants on delete set null,
  product_name text not null,
  color_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price_cents integer not null,
  expires_at timestamptz not null,
  released boolean not null default false    -- true = stock déjà rendu (session expirée)
);
create index on stock_reservations (reservation_id);

-- ---------- Sécurité (RLS) ----------
alter table products enable row level security;
alter table variants enable row level security;
alter table product_images enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table stock_reservations enable row level security;

create policy "catalogue en ligne lisible par tous" on products
  for select using (is_active);
create policy "coloris en ligne lisibles par tous" on variants
  for select using (exists (select 1 from products p where p.id = product_id and p.is_active));
create policy "photos en ligne lisibles par tous" on product_images
  for select using (exists (select 1 from variants v join products p on p.id = v.product_id where v.id = variant_id and p.is_active));
-- Commandes et réservations : aucune règle, donc aucun accès avec les clés publiques.

-- ---------- Fonctions de stock (appelées par le serveur uniquement) ----------

-- Rend le stock des réservations données et les marque « released ».
create function release_rows(p_ids uuid[]) returns void
language sql as $$
  with freed as (
    update stock_reservations set released = true
    where id = any(p_ids) and not released
    returning variant_id, quantity
  )
  update variants v set stock = v.stock + f.total
  from (select variant_id, sum(quantity)::int as total from freed group by variant_id) f
  where v.id = f.variant_id;
$$;

create function release_reservation(p_reservation uuid) returns void
language sql as $$
  select release_rows(array(select id from stock_reservations where reservation_id = p_reservation));
$$;

-- Réserve tout le panier ou rien. Renvoie false si une pièce manque.
create function reserve_stock(p_reservation uuid, p_items jsonb, p_expires timestamptz) returns boolean
language plpgsql as $$
declare
  it record;
begin
  -- Filet de sécurité si le webhook « session expirée » n'est jamais arrivé.
  perform release_rows(array(select id from stock_reservations where expires_at < now() and not released));
  delete from stock_reservations where released and expires_at < now() - interval '7 days';

  begin
    for it in
      select (e->>'variant_id')::uuid as variant_id, (e->>'quantity')::int as quantity, (e->>'unit_price_cents')::int as unit_price_cents
      from jsonb_array_elements(p_items) e
      order by 1  -- toujours le même ordre de verrouillage : pas d'interblocage entre deux paniers
    loop
      update variants set stock = stock - it.quantity where id = it.variant_id and stock >= it.quantity;
      if not found then
        raise exception 'stock_insuffisant';
      end if;
      insert into stock_reservations (reservation_id, variant_id, product_name, color_name, quantity, unit_price_cents, expires_at)
      select p_reservation, v.id, p.name, v.color_name, it.quantity, it.unit_price_cents, p_expires
      from variants v join products p on p.id = v.product_id where v.id = it.variant_id;
    end loop;
  exception when raise_exception then
    return false;  -- le bloc est annulé en entier : rien n'a été réservé
  end;
  return true;
end;
$$;

-- Paiement confirmé : crée la commande à partir de la réservation. Rejouable sans risque
-- (Stripe peut envoyer deux fois le même événement).
create function complete_order(p_reservation uuid, p_order jsonb) returns uuid
language plpgsql as $$
declare
  o_id uuid;
begin
  select id into o_id from orders where stripe_session_id = p_order->>'stripe_session_id';
  if found then
    return o_id;
  end if;

  insert into orders (stripe_session_id, email, customer_name, phone, relay_id, relay_name, relay_address, relay_zip, relay_city,
                      subtotal_cents, shipping_cents, discount_cents, total_cents)
  values (p_order->>'stripe_session_id', p_order->>'email', p_order->>'customer_name', p_order->>'phone',
          p_order->>'relay_id', p_order->>'relay_name', p_order->>'relay_address', p_order->>'relay_zip', p_order->>'relay_city',
          (p_order->>'subtotal_cents')::int, (p_order->>'shipping_cents')::int, (p_order->>'discount_cents')::int, (p_order->>'total_cents')::int)
  returning id into o_id;

  insert into order_items (order_id, variant_id, product_name, color_name, quantity, unit_price_cents)
  select o_id, variant_id, product_name, color_name, quantity, unit_price_cents
  from stock_reservations where reservation_id = p_reservation;

  -- Cas rare : payé après expiration, le stock avait été rendu. On le reprend (sans passer sous zéro).
  update variants v set stock = greatest(v.stock - r.total, 0)
  from (select variant_id, sum(quantity)::int as total from stock_reservations
        where reservation_id = p_reservation and released group by variant_id) r
  where v.id = r.variant_id;

  delete from stock_reservations where reservation_id = p_reservation;
  return o_id;
end;
$$;

-- Boutons −/+ de l'admin.
create function adjust_stock(p_variant uuid, p_delta integer) returns void
language sql as $$
  update variants
  set stock = greatest(stock + p_delta, 0),
      stock_initial = greatest(stock_initial, stock + p_delta)
  where id = p_variant;
$$;

-- ---------- Limite anti-abus ----------
-- Compte les essais d'un visiteur (connexion, paiement, code promo) par fenêtre de temps.
-- La clé contient une empreinte de son adresse IP, jamais l'adresse elle-même.
create table rate_limits (
  key text not null,
  bucket bigint not null,
  hits integer not null default 1,
  expires_at timestamptz not null,
  primary key (key, bucket)
);
alter table rate_limits enable row level security;  -- aucune règle : inaccessible avec les clés publiques

-- true tant que la clé reste sous p_max essais dans la fenêtre de p_window secondes en cours.
create function rate_limit(p_key text, p_max integer, p_window integer) returns boolean
language plpgsql as $$
declare
  v_bucket bigint := floor(extract(epoch from now()) / p_window);
  v_hits integer;
begin
  delete from rate_limits where expires_at < now();
  insert into rate_limits (key, bucket, expires_at)
  values (p_key, v_bucket, now() + make_interval(secs => p_window))
  on conflict (key, bucket) do update set hits = rate_limits.hits + 1
  returning hits into v_hits;
  return v_hits <= p_max;
end;
$$;

revoke execute on function release_rows(uuid[]), release_reservation(uuid), reserve_stock(uuid, jsonb, timestamptz),
  complete_order(uuid, jsonb), adjust_stock(uuid, integer), rate_limit(text, integer, integer) from public, anon, authenticated;

-- Droits explicites, pour ne pas dépendre des réglages par défaut du projet Supabase :
-- le serveur (service_role, clé secrète) peut tout faire ; les clés publiques ne font que lire le catalogue,
-- et la RLS ci-dessus limite encore cette lecture aux articles en ligne.
grant usage on schema public to anon, authenticated, service_role;
grant all on all tables in schema public to service_role;
grant all on all sequences in schema public to service_role;
grant execute on all functions in schema public to service_role;
grant select on products, variants, product_images to anon, authenticated;

-- ---------- Photos ----------
-- Bucket public en lecture ; l'envoi passe par le serveur (clé secrète), donc aucune règle d'écriture.
-- Même si une clé fuyait, le bucket n'accepte que des images JPEG ou PNG de 4 Mo au plus.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('produits', 'produits', true, 4194304, array['image/jpeg', 'image/png'])
on conflict (id) do update set public = true, file_size_limit = 4194304, allowed_mime_types = array['image/jpeg', 'image/png'];

-- ---------- Données de départ : 1 casquette, 3 coloris, 3 pièces chacun ----------
with p as (
  insert into products (name, slug, description, price_cents)
  values ('Casquette Helicaps', 'casquette-helicaps', '[Description de la casquette : matière, coupe, finitions.]', 9000)
  returning id
), v as (
  insert into variants (product_id, color_name, color_slug, swatch_hex, stock, stock_initial, sort_order)
  select p.id, c.name, c.slug, c.hex, 3, 3, c.pos
  from p, (values ('Noir', 'noir', '#1f1f1f', 0), ('Bleu', 'bleu', '#24427c', 1), ('Vert', 'vert', '#2f5d42', 2)) as c(name, slug, hex, pos)
  returning id, color_slug, color_name
)
insert into product_images (variant_id, url, alt, kind)
select id, '/images/placeholders/cap-' || color_slug || '.svg', 'Casquette Helicaps, ' || lower(color_name) || ', visuel provisoire', 'studio'
from v;
