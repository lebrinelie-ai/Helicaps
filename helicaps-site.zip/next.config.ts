import type { NextConfig } from 'next'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL

// Posés sur toutes les réponses. La Content-Security-Policy, elle, change à chaque page : voir src/proxy.ts.
const securityHeaders = [
  // Le navigateur ne « devine » pas le type d'un fichier (une image reste une image).
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  // Le site ne peut pas être affiché dans le cadre d'un autre site (détournement de clic).
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=(), usb=()' },
  // Un an en HTTPS obligatoire. Sans « includeSubDomains » : le domaine peut avoir d'autres usages (e-mail…).
  { key: 'Strict-Transport-Security', value: 'max-age=31536000' },
]

const config: NextConfig = {
  poweredByHeader: false,
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: supabaseUrl ? [new URL('/storage/v1/object/public/**', supabaseUrl)] : [],
  },
  // Les photos sont réduites dans le navigateur avant l'envoi (voir PhotoInput).
  experimental: { serverActions: { bodySizeLimit: '4mb' } },
  async headers() {
    // /relais pose ses propres en-têtes : c'est la seule page que notre site a le droit d'encadrer.
    return [{ source: '/((?!relais).*)', headers: securityHeaders }]
  },
}

export default config
